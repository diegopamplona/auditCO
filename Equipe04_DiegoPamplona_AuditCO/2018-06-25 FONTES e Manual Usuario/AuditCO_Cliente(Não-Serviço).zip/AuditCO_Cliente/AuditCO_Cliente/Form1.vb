﻿Imports System.Threading

Public Class Form1
    'Dim StringInserir As String
    'Dim Cabecalho As String
    Dim Rnd As Random = New Random
    Dim TempoColeta As Integer = PegaParametro("GERAL", "TEMPOCOLETA")
    Private Sub btColetaJa_Click(sender As Object, e As EventArgs) Handles btColetaJa.Click
        'CriaXML()
        'Dim RndTemp As Random = New Random
        'PopulaDadosAleatoriosColeta()
        'Cabecalho = "Insert into Coletas (datacoleta,horacoleta,nmhost,nmuserlogado,nmcontdomhost,uptimehost,timezonehost,prochost,qtdcorhost,nmsoatualhost,platsoatualhost,lingsoatualhost,qtdmemhost,qtdmemdisphost,discosohost,formatdiscosohost,tamtotdiscosohost,tamdispdiscosohost,nomeniccabo,descniccabo,macaddressniccabo,enderipniccabo,nomenicsemfio,descnicsemfio,macaddressnicsemfio,enderipnicsemfio,placavideo,resolucaoatual,impressorainst1,impressorainst2,impressorainst3,impressorainst4,impressorainst5,impressorainst6,impressorainst7,chavewindows,chaveoffice,instanciasql,programinstal1,programinstal2,programinstal3,programinstal4,programinstal5,programinstal6,programinstal7,programinstal8,programinstal9,programinstal10,programinstal11,programinstal12,programinstal13,programinstal14,programinstal15,programinstal16,programinstal17,programinstal18,programinstal19,programinstal20,programinstal21,programinstal22,programinstal23,programinstal24,programinstal25,programinstal26,programinstal27,programinstal28,programinstal29,programinstal30,programinstal31,programinstal32,programinstal33,programinstal34,programinstal35,programinstal36,programinstal37,programinstal38,programinstal39,programinstal40,programinstal41,programinstal42,programinstal43,programinstal44,programinstal45,programinstal46,programinstal47,programinstal48,programinstal49,programinstal50,programinstal51,programinstal52,programinstal53,programinstal54,programinstal55,programinstal56,programinstal57,programinstal58,programinstal59,programinstal60,programinstal61,programinstal62,programinstal63,programinstal64,programinstal65,programinstal66,programinstal67,programinstal68,programinstal69,programinstal70,programinstal71,programinstal72,programinstal73,programinstal74,programinstal75,programinstal76,programinstal77,programinstal78,programinstal79,programinstal80,programinstal81,programinstal82,programinstal83,programinstal84,programinstal85,programinstal86,programinstal87,programinstal88,programinstal89,programinstal90,programinstal91,programinstal92,programinstal93,programinstal94) values ("
        ' StringInserir = StringCompletaComando()
        'GravaLog(Cabecalho & PopulaDadosAleatoriosColeta().ToString & ")")
        'ExecutaComando(Cabecalho & PopulaDadosAleatoriosColeta().ToString & ")")
        'GravaLog(Cabecalho & StringInserir & "),")
        'For i = 0 To 9997
        'GravaLog("(" & StringInserir & "),")
        ' Next
        'GravaLog("(" & StringInserir & ")")
        Do While True
            Thread.Sleep(5000)


            PopulaDadosAleatoriosColeta()
            ExecutaColeta()
            If PegaParametro("GERAL", "CRIAXML") = "SIM" Then
                CriaXMLImportacao()
            End If
        Loop
    End Sub
End Class
