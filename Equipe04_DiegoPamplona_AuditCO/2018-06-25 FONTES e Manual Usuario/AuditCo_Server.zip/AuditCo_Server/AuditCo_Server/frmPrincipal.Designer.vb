﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPrincipal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPrincipal))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.UsuáriosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CadastrarUsuáriosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComputadoresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportarXMLDeCadastroToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CadastrarInformaçõesAdicionaisToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdministraçãoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportAllHostsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RelatoriosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RelDetalhamentoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RelUsuariosCadastradosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UsuáriosToolStripMenuItem, Me.ComputadoresToolStripMenuItem, Me.AdministraçãoToolStripMenuItem, Me.RelatoriosToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(575, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'UsuáriosToolStripMenuItem
        '
        Me.UsuáriosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CadastrarUsuáriosToolStripMenuItem})
        Me.UsuáriosToolStripMenuItem.Name = "UsuáriosToolStripMenuItem"
        Me.UsuáriosToolStripMenuItem.Size = New System.Drawing.Size(64, 20)
        Me.UsuáriosToolStripMenuItem.Text = "Usuários"
        '
        'CadastrarUsuáriosToolStripMenuItem
        '
        Me.CadastrarUsuáriosToolStripMenuItem.Name = "CadastrarUsuáriosToolStripMenuItem"
        Me.CadastrarUsuáriosToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.CadastrarUsuáriosToolStripMenuItem.Text = "Cadastrar Usuários"
        '
        'ComputadoresToolStripMenuItem
        '
        Me.ComputadoresToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ImportarXMLDeCadastroToolStripMenuItem, Me.CadastrarInformaçõesAdicionaisToolStripMenuItem})
        Me.ComputadoresToolStripMenuItem.Name = "ComputadoresToolStripMenuItem"
        Me.ComputadoresToolStripMenuItem.Size = New System.Drawing.Size(98, 20)
        Me.ComputadoresToolStripMenuItem.Text = "Computadores"
        '
        'ImportarXMLDeCadastroToolStripMenuItem
        '
        Me.ImportarXMLDeCadastroToolStripMenuItem.Name = "ImportarXMLDeCadastroToolStripMenuItem"
        Me.ImportarXMLDeCadastroToolStripMenuItem.Size = New System.Drawing.Size(251, 22)
        Me.ImportarXMLDeCadastroToolStripMenuItem.Text = "Importar XML de Cadastro"
        '
        'CadastrarInformaçõesAdicionaisToolStripMenuItem
        '
        Me.CadastrarInformaçõesAdicionaisToolStripMenuItem.Name = "CadastrarInformaçõesAdicionaisToolStripMenuItem"
        Me.CadastrarInformaçõesAdicionaisToolStripMenuItem.Size = New System.Drawing.Size(251, 22)
        Me.CadastrarInformaçõesAdicionaisToolStripMenuItem.Text = "Cadastrar Informações Adicionais"
        '
        'AdministraçãoToolStripMenuItem
        '
        Me.AdministraçãoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReportAllHostsToolStripMenuItem})
        Me.AdministraçãoToolStripMenuItem.Name = "AdministraçãoToolStripMenuItem"
        Me.AdministraçãoToolStripMenuItem.Size = New System.Drawing.Size(96, 20)
        Me.AdministraçãoToolStripMenuItem.Text = "Administração"
        '
        'ReportAllHostsToolStripMenuItem
        '
        Me.ReportAllHostsToolStripMenuItem.Name = "ReportAllHostsToolStripMenuItem"
        Me.ReportAllHostsToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.ReportAllHostsToolStripMenuItem.Text = "Report All Hosts"
        '
        'RelatoriosToolStripMenuItem
        '
        Me.RelatoriosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RelToolStripMenuItem, Me.RelDetalhamentoToolStripMenuItem, Me.RelUsuariosCadastradosToolStripMenuItem})
        Me.RelatoriosToolStripMenuItem.Name = "RelatoriosToolStripMenuItem"
        Me.RelatoriosToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
        Me.RelatoriosToolStripMenuItem.Text = "Relatorios"
        '
        'RelToolStripMenuItem
        '
        Me.RelToolStripMenuItem.Name = "RelToolStripMenuItem"
        Me.RelToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.RelToolStripMenuItem.Text = "Rel - Hosts Cadastrados"
        '
        'RelDetalhamentoToolStripMenuItem
        '
        Me.RelDetalhamentoToolStripMenuItem.Name = "RelDetalhamentoToolStripMenuItem"
        Me.RelDetalhamentoToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.RelDetalhamentoToolStripMenuItem.Text = "Rel - Detalhamento Host"
        '
        'RelUsuariosCadastradosToolStripMenuItem
        '
        Me.RelUsuariosCadastradosToolStripMenuItem.Name = "RelUsuariosCadastradosToolStripMenuItem"
        Me.RelUsuariosCadastradosToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.RelUsuariosCadastradosToolStripMenuItem.Text = "Rel - Usuarios Cadastrados"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(13, 28)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(556, 357)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'frmPrincipal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(575, 391)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmPrincipal"
        Me.Text = "AuditCO - Server - Auditoria e Compliance de Hardware e Softwares Microsoft"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents UsuáriosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CadastrarUsuáriosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ComputadoresToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ImportarXMLDeCadastroToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CadastrarInformaçõesAdicionaisToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AdministraçãoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReportAllHostsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RelatoriosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RelToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RelDetalhamentoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RelUsuariosCadastradosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PictureBox1 As PictureBox
End Class
