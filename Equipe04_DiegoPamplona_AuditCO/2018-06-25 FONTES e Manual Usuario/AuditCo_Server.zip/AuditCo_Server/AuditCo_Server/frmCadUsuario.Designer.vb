﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCadUsuario
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtnomuser = New System.Windows.Forms.TextBox()
        Me.cbpapeluser = New System.Windows.Forms.ComboBox()
        Me.btcadastraruser = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pbImageUser = New System.Windows.Forms.PictureBox()
        Me.btlocalizarfotouser = New System.Windows.Forms.Button()
        CType(Me.pbImageUser, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nome Usuário:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(19, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Tipo Usuário:"
        '
        'txtnomuser
        '
        Me.txtnomuser.Location = New System.Drawing.Point(95, 12)
        Me.txtnomuser.Name = "txtnomuser"
        Me.txtnomuser.Size = New System.Drawing.Size(270, 20)
        Me.txtnomuser.TabIndex = 4
        '
        'cbpapeluser
        '
        Me.cbpapeluser.FormattingEnabled = True
        Me.cbpapeluser.Items.AddRange(New Object() {"Administrador", "Contabilidade"})
        Me.cbpapeluser.Location = New System.Drawing.Point(96, 39)
        Me.cbpapeluser.Name = "cbpapeluser"
        Me.cbpapeluser.Size = New System.Drawing.Size(129, 21)
        Me.cbpapeluser.TabIndex = 5
        Me.cbpapeluser.Text = "Administrador"
        '
        'btcadastraruser
        '
        Me.btcadastraruser.Location = New System.Drawing.Point(150, 299)
        Me.btcadastraruser.Name = "btcadastraruser"
        Me.btcadastraruser.Size = New System.Drawing.Size(75, 23)
        Me.btcadastraruser.TabIndex = 6
        Me.btcadastraruser.Text = "Cadastrar"
        Me.btcadastraruser.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(19, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Foto usuario"
        '
        'pbImageUser
        '
        Me.pbImageUser.Location = New System.Drawing.Point(96, 72)
        Me.pbImageUser.Name = "pbImageUser"
        Me.pbImageUser.Size = New System.Drawing.Size(269, 158)
        Me.pbImageUser.TabIndex = 8
        Me.pbImageUser.TabStop = False
        '
        'btlocalizarfotouser
        '
        Me.btlocalizarfotouser.Location = New System.Drawing.Point(276, 236)
        Me.btlocalizarfotouser.Name = "btlocalizarfotouser"
        Me.btlocalizarfotouser.Size = New System.Drawing.Size(89, 23)
        Me.btlocalizarfotouser.TabIndex = 9
        Me.btlocalizarfotouser.Text = "Localizar Foto"
        Me.btlocalizarfotouser.UseVisualStyleBackColor = True
        '
        'frmCadUsuario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(378, 334)
        Me.Controls.Add(Me.btlocalizarfotouser)
        Me.Controls.Add(Me.pbImageUser)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btcadastraruser)
        Me.Controls.Add(Me.cbpapeluser)
        Me.Controls.Add(Me.txtnomuser)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmCadUsuario"
        Me.Text = "AuditCO - Server. - Cadastro de Usuários"
        CType(Me.pbImageUser, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtnomuser As TextBox
    Friend WithEvents cbpapeluser As ComboBox
    Friend WithEvents btcadastraruser As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents pbImageUser As PictureBox
    Friend WithEvents btlocalizarfotouser As Button
End Class
