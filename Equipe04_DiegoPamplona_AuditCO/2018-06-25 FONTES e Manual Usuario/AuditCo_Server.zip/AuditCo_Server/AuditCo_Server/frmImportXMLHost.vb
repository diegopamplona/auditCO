﻿

Public Class frmImportXMLHost


    Private Sub btImportXML_Click(sender As Object, e As EventArgs) Handles btImportXML.Click
        carregaTreeView(tbxmlaimportar.Text, tvxmlimportado)
    End Sub
    Private Sub btLocalizarXML_Click(sender As Object, e As EventArgs) Handles btLocalizarXML.Click
        Using CaixaDialogo As New OpenFileDialog
            If CaixaDialogo.ShowDialog() <> DialogResult.OK Then Return
            tbxmlaimportar.Text = CaixaDialogo.FileName.ToString
        End Using
        ImportaXMLtoBD(tbxmlaimportar.Text)

    End Sub
End Class