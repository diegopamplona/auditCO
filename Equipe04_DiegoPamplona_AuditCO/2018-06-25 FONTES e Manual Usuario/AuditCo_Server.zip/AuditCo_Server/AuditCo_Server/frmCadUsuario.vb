﻿Imports System.Data.SqlClient
Imports System.IO

Public Class frmCadUsuario

    Dim DataAtual As Date = Date.Now.Day & "-" & Date.Now.Month & "-" & Date.Now.Year
    Private Sub btcadastraruser_Click(sender As Object, e As EventArgs) Handles btcadastraruser.Click
        Try
            CadastraUsuario(DataAtual, txtnomuser.Text, cbpapeluser.SelectedItem, pbImageUser.ImageLocation)
        Catch ex As Exception
            GravaLog(ex.Message)
        End Try
    End Sub

    Private Sub btlocalizarfotouser_Click(sender As Object, e As EventArgs) Handles btlocalizarfotouser.Click
        Using CaixaDialogo As New OpenFileDialog
            If CaixaDialogo.ShowDialog() <> DialogResult.OK Then Return
            pbImageUser.Image = Image.FromFile(CaixaDialogo.FileName)
            pbImageUser.ImageLocation = CaixaDialogo.FileName
        End Using
    End Sub
End Class