﻿Imports System.Data.OleDb
Imports System.Net.Mail
Imports Microsoft.VisualBasic.Devices
Imports Microsoft.Win32
Imports System.Xml
Imports System.Net.NetworkInformation
Imports System.Drawing.Printing
Imports Microsoft.SqlServer.Management.Smo
Imports System.ServiceProcess
Imports System.Management
Imports System.Reflection
Imports System.IO
Imports System.Data.SqlClient

Public Class SistemaOperacional

    Public Shared Function Linguagem()
        Dim ComputerInfo As ComputerInfo = New ComputerInfo
        Dim Cult_Instalada As String = ComputerInfo.InstalledUICulture.ToString
        Return Cult_Instalada
    End Function

    Public Shared Function Nome()
        Dim ComputerInfo As ComputerInfo = New ComputerInfo
        Dim Nom_SO As String = ComputerInfo.OSFullName.ToString
        Return Nom_SO
    End Function

    Public Shared Function Plataforma()
        Dim PlataformaDetectada As String
        Dim pa As String = Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE")
        PlataformaDetectada = IIf((String.IsNullOrEmpty(pa) Or String.Compare(pa, 0, "x86", 0, 3, True) = 0), 32, 64).ToString
        Return PlataformaDetectada & " Bits"
    End Function

    Public Shared Function ServicePack()
        Dim Versao_SO As String = Environment.OSVersion.ServicePack.ToString
        Return Versao_SO
    End Function

End Class

Public Class Memoria
    Public Shared Function MemoriaFisicaTotal()
        Dim ComputerInfo As ComputerInfo = New ComputerInfo
        Dim MemFisTot As String = FormataNumero(ComputerInfo.TotalPhysicalMemory.ToString)
        Return MemFisTot
    End Function

    Public Shared Function MemoriaFisicaDisponivel()
        Dim ComputerInfo As ComputerInfo = New ComputerInfo
        Dim MemFisTot As String = FormataNumero(ComputerInfo.AvailablePhysicalMemory.ToString)
        Return MemFisTot
    End Function

End Class

Public Class DiscosLocais

    Dim NomeDisco As String

    'If strNomeDoServico.Contains(NomeInstancia) Then
    '            NomeSQL = strNomeDoServico
    ''GravaLog("Encontrei o Serviço: " & strNomeDoServico)
    'End If
    Public Shared Function Nome(ByVal Drive As String)
        Dim NomeDisco As String
        Dim Infodrive As IO.DriveInfo = New IO.DriveInfo(Drive)
        'If NomedDisco Then
        Return Infodrive.Name
    End Function

    Public Shared Function Rotulo(ByVal Drive As String)
        Dim Infodrive As IO.DriveInfo = New IO.DriveInfo(Drive)
        Return Infodrive.VolumeLabel
    End Function

    Public Shared Function Tipo(ByVal Drive As String)
        Dim Infodrive As IO.DriveInfo = New IO.DriveInfo(Drive)
        Return Infodrive.DriveType.ToString
    End Function

    Public Shared Function Formato(ByVal Drive As String)
        Dim Infodrive As IO.DriveInfo = New IO.DriveInfo(Drive)
        Return Infodrive.DriveFormat
    End Function

    Public Shared Function TamanhoTotal(ByVal Drive As String)
        Dim Infodrive As IO.DriveInfo = New IO.DriveInfo(Drive)
        Return FormataNumero(Infodrive.TotalSize)
    End Function

    Public Shared Function TamanhoDisponivel(ByVal Drive As String)
        Dim Infodrive As IO.DriveInfo = New IO.DriveInfo(Drive)
        Return FormataNumero(Infodrive.TotalFreeSpace)
    End Function

End Class

Public Class ProdutosMicrosoft
    Public Shared Function ChaveWindows()
        Dim ChaveAtualWindows As String = GetProductKey("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\", "DigitalProductId")
        Return ChaveAtualWindows
    End Function

    Public Shared Function ChaveOffice()
        Dim ChaveAtualOffice As String = GetProductKey("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Office\14.0\Registration\{90140000-0011-0000-1000-0000000FF1CE}", "DigitalProductId")
        Return ChaveAtualOffice
    End Function
End Class

Public Class Monitor
    Public Shared Function ResolucaoTelaAtual() As String
        Dim intX As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim intY As Integer = Screen.PrimaryScreen.Bounds.Height
        Return intX & " X " & intY
    End Function
    Public Shared Function PlacaVideo()
        Dim NomePlacadeVideo = String.Empty
        Dim WmiSelect As New ManagementObjectSearcher("root\CIMV2", "SELECT * FROM Win32_VideoController")
        For Each WmiResults As ManagementObject In WmiSelect.Get()
            NomePlacadeVideo = WmiResults.GetPropertyValue("Name").ToString & " com " & FormataNumero(WmiResults.GetPropertyValue("AdapterRam").ToString) & " Dedicado de RAM"
            If (Not String.IsNullOrEmpty(NomePlacadeVideo)) Then
                Exit For
            End If
        Next
        Return NomePlacadeVideo
    End Function
End Class

Public Class GravaLogNovo
    Public Shared Function GravaLogNovo(ByVal Mensagem As String)
        Dim NMARQLOG As String = My.Application.Info.DirectoryPath & Date.Now.Year & Date.Now.Month & Date.Now.Day & Date.Now.Hour & Date.Now.Minute & Date.Now.Second & ".log"
        Dim ESCRITOR As IO.FileStream
        Dim ESCRITORTEXTO As IO.StreamWriter
        If System.IO.File.Exists(NMARQLOG) Then
            ESCRITOR = New System.IO.FileStream(NMARQLOG, IO.FileMode.Append, IO.FileAccess.Write)
        Else
            ESCRITOR = New System.IO.FileStream(NMARQLOG, IO.FileMode.CreateNew, IO.FileAccess.Write)
        End If
        ESCRITORTEXTO = New System.IO.StreamWriter(ESCRITOR)
        ESCRITORTEXTO.WriteLine(DateTime.Now & " - " & Mensagem)
        ESCRITORTEXTO.Close()
        Return True
    End Function
End Class

Public Class Computador
    Public Shared Function Nome()
        Dim NomeComputador As String = My.Computer.Name()
        Return NomeComputador
    End Function
    Public Shared Function UsuarioAtual()
        Dim Usuario As String = Environment.UserName
        Return Usuario
    End Function
    Public Shared Function ControladorDominio()
        Dim logonserver As String = Environment.GetEnvironmentVariable("LOGONSERVER")
        Return logonserver.Replace("\", "")
    End Function
    Public Shared Function Uptime()
        Dim time As String = String.Empty
        time += Math.Round(Environment.TickCount / 86400000) & " dias e "
        time += Math.Round(Environment.TickCount / 3600000 Mod 24) & " horas e "
        time += Math.Round(Environment.TickCount / 120000 Mod 60) & " minutos e "
        time += Math.Round(Environment.TickCount / 1000 Mod 60) & " segundos"
        Return time
    End Function

    Public Shared Function TimeZoneAtual()
        Dim curTimeZone As TimeZone = TimeZone.CurrentTimeZone
        Dim MTimezoneAtual = curTimeZone.StandardName
        Return MTimezoneAtual
    End Function


End Class

Public Class Processador
    Public Shared Function Nome()
        Dim m_LM As RegistryKey
        Dim m_HW As RegistryKey
        Dim m_Des As RegistryKey
        Dim m_System As RegistryKey
        Dim m_CPU As RegistryKey
        Dim m_Info As RegistryKey
        Dim NomeProcessador As String
        m_LM = Registry.LocalMachine
        m_HW = m_LM.OpenSubKey("HARDWARE")
        m_Des = m_HW.OpenSubKey("DESCRIPTION")
        m_System = m_Des.OpenSubKey("SYSTEM")
        m_CPU = m_System.OpenSubKey("CentralProcessor")
        m_Info = m_CPU.OpenSubKey("0")

        NomeProcessador = m_Info.GetValue("ProcessorNameString") '& " " & m_Info.GetValue("Identifier") & " " & m_Info.GetValue("~Mhz") & "MHz"
        Return NomeProcessador
    End Function

    Public Shared Function Core()
        Dim QtdCore As Integer = Environment.ProcessorCount()
        Dim Quantidade As String = QtdCore & " Cores"
        Return Quantidade
    End Function

End Class

Public Class SQLServer

    Public Shared Function PegaNomeSQLServer() As String
        'Nome do PC local
        Dim NomeHost As String = Environment.MachineName
        ' nome do serviço do SQL Server Express
        Dim NomeInstancia As String = "MSSQL"
        Dim NomeSQL As String = String.Empty

        ' Inclua uma referência a : System.ServiceProcess;
        Dim servicos As ServiceController() = ServiceController.GetServices()
        ' percorre os serviços 
        For Each servico As ServiceController In servicos
            If servico Is Nothing Then
                Continue For
            End If

            Dim strNomeDoServico As String = servico.ServiceName

            If strNomeDoServico.Contains(NomeInstancia) Then
                NomeSQL = strNomeDoServico
                ''GravaLog("Encontrei o Serviço: " & strNomeDoServico)
            End If
        Next

        Dim IndiceInicio As Integer = NomeSQL.IndexOf("$")

        If IndiceInicio > -1 Then
            'NomeSQL=NomeDoSeuPC\SQLEXPRESS;
            NomeSQL = NomeHost + "\" + NomeSQL.Substring(IndiceInicio + 1)
        End If

        Return NomeSQL
    End Function
End Class

Module Module1

    'Variaveis Gerais
    Dim DataHoje As String = Date.Now.Year & "-" & Date.Now.Month & "-" & Date.Now.Day
    Dim HoraAtual As String = Date.Now.Hour & ":" & Date.Now.Minute & ":" & Date.Now.Second
    Dim NMARQLOG As String = My.Application.Info.DirectoryPath & "\Logs\" & "AuditCO_Cliente" & Date.Now.Year & Date.Now.Month & Date.Now.Day & Date.Now.Hour & Date.Now.Minute & Date.Now.Second & ".log"
    Dim ESCRITOR As IO.FileStream
    Dim ESCRITORTEXTO As IO.StreamWriter
    Dim NRPAREME As Integer = 1
    Dim NMDIRBKP As String
    Dim INDELARQ As Integer
    Dim INMAPRED As Integer
    Dim LETMAPRE As String
    Dim DSCAMMAP As String
    Dim NMDESTIN As String
    Dim ENDREMEX As String
    Dim ENDDESTX As String
    Dim ENDSMTPX As String
    Dim DSPORTAX As Integer = 0
    Dim DSUSUARI As String
    Dim DSSENHAX As String
    Dim AUXORIGX As String
    Dim AUXDESTX As String
    Dim EXTNMPES As String
    Dim INLIMDES As Integer
    Dim ComputerInfo As ComputerInfo = New ComputerInfo
    Dim StringComandoColeta As String
    Dim ContagemCampos As Integer = 0
    'Arrays para Populacao Aleatoria das tabelas
    Dim ArrayProgramasInstalados As ArrayList = New ArrayList
    Dim ArrayNomesUsuarios As ArrayList = New ArrayList
    Dim ArrayNomeHosts As ArrayList = New ArrayList
    Dim ArrayControladorDominio As ArrayList = New ArrayList
    Dim ArrayModelProcessadores As ArrayList = New ArrayList
    Dim ArrayQtdCores As ArrayList = New ArrayList
    Dim ArrayVersoesWindows As ArrayList = New ArrayList
    Dim ArrayMemoriaDisponivel As ArrayList = New ArrayList
    Dim ArrayMemoriaTotal As ArrayList = New ArrayList
    Dim ArrayDiscoTotal As ArrayList = New ArrayList
    Dim ArrayDiscoDisponivel As ArrayList = New ArrayList
    Dim ArrayUptime As ArrayList = New ArrayList
    Dim conteudoArquivo As New XmlDocument

    'Variaveis de Conexão SQL Server
    Public Const NmBancoSQLServer As String = "AuditCODB"
    Public Const NmTabelaParametros As String = "Coletas"
    Public Const NmScriptCriatabelaParametros As String = "..\..\Scripts\CriaTabelaParametros.sql"
    Public Const NmScriptCriaBancoGeraDetiDB As String = "..\..\Scripts\CriaGeraDetiBD.sql"
    Public strConnString As String = ""

    'Declaracao das Funcoes GetFileAtributes e GetPrivaProfileString
    Public Declare Function GetFileAttributes Lib "kernel32" Alias "GetFileAttributesA" (ByVal lpFileName As String) As Integer

    Public Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" (
      ByVal lpApplicationName As String,
      ByVal lpKeyName As String,
      ByVal lpDefault As String,
      ByVal lpReturnedString As String,
      ByVal nSize As Integer,
      ByVal lpFileName As String) As Integer

    'Declaracao das Funcoes de Mapeamento de Recurso de Rede
    Public Declare Function WNetAddConnection2 Lib "mpr.dll" Alias "WNetAddConnection2A" _
                           (ByRef lpNetResource As NETRESOURCE, ByVal lpPassword As String,
                           ByVal lpUserName As String, ByVal dwFlags As Integer) As Integer

    Public Declare Function WNetCancelConnection2 Lib "mpr" Alias "WNetCancelConnection2A" _
                            (ByVal lpName As String, ByVal dwFlags As Integer, ByVal fForce As Integer) As Integer

    Public Structure NETRESOURCE
        Public dwScope As Integer
        Public dwType As Integer
        Public dwDisplayType As Integer
        Public dwUsage As Integer
        Public lpLocalName As String
        Public lpRemoteName As String
        Public lpComment As String
        Public lpProvider As String
    End Structure

    Public Const ForceDisconnect As Integer = 1
    Public Const RESOURCETYPE_DISK As Long = &H1

    'Declaracao das Funcoes de Busca de Informacoes de Disco Locais
    Partial Public Class Win32API

        Public Declare Function GetDiskFreeSpace Lib "kernel32" _
            Alias "GetDiskFreeSpaceA" (ByVal RootPathName As String,
                                                     ByRef SectorsPerCluster As Integer,
                                                     ByRef BytesPerSector As Integer,
                                                     ByRef NumberOfFreeClusters As Integer,
                                                     ByRef TotalNumberOfClusters As Integer) As Integer

        Public Declare Function GetDiskFreeSpaceEx Lib "kernel32" _
            Alias "GetDiskFreeSpaceExA" (ByVal RootPathName As String,
                                                         ByRef FreeBytesAvailableToCaller As Integer,
                                                         ByRef TotalNumberOfBytes As Integer,
                                                         ByRef TotalNumberOfFreeBytes As UInt32) As Integer

        Public Declare Function GetDriveType Lib "kernel32" _
             Alias "GetDriveTypeA" (ByVal nDrive As String) As Integer

    End Class


    Public Function CriaBancoDeDados(ByVal strNomeDB As String)
        Dim dbServidor As New Server(SQLServer.PegaNomeSQLServer())
        Dim BancodeDados As New Database(dbServidor, strNomeDB)
        'cria o banco de dados
        BancodeDados.Create()
    End Function

    Public Function ExecutaScriptSQL_CriarTabelaAluno(ByVal strCaminhoArquivo As String)

        Dim NomeAssemblyApplicacao As Assembly = Assembly.GetEntryAssembly()
        Dim diretorioAplicacao As String = Path.GetDirectoryName(NomeAssemblyApplicacao.Location)
        Dim caminhoArquivo As String = Path.Combine(diretorioAplicacao, strCaminhoArquivo)
        Dim Arquivo As New FileInfo(caminhoArquivo)
        Dim strScript As String = Arquivo.OpenText().ReadToEnd()

        strScript = strScript.Replace("GO" & vbCr & vbLf, "")

        Using conn As New SqlConnection(MontaStringDeConexao())
            conn.Open()
            Dim cmd As New SqlCommand(strScript, conn)
            Try
                cmd.ExecuteNonQuery()
            Catch excp As Exception
                Throw
            End Try
        End Using
    End Function

    Public Function ExecutaComando(ByVal ComandoExecutar As String)
        Using conn As New SqlConnection(MontaStringDeConexao())
            conn.Open()
            Dim cmd As New SqlCommand(ComandoExecutar, conn)
            Try
                cmd.ExecuteNonQuery()
                conn.Close()
            Catch exc As Exception
                Throw
            End Try
        End Using

    End Function

    Public Function MontaStringDeConexao() As String
        Dim NomeSQLServer As String = SQLServer.PegaNomeSQLServer()

        'String considerando o usuario ja conectado no Windows.
        Dim strConnString As String = "Data Source=" & NomeSQLServer & ";" & "Initial Catalog=" + NmBancoSQLServer + ";Integrated Security=True"
        Return strConnString
    End Function
    Public Function MapeiaDrive(ByVal LetraDrive As String, ByVal Caminho As String) As Boolean

        Dim recursorede As NETRESOURCE
        Dim strUsername As String
        Dim strPassword As String

        recursorede = New NETRESOURCE
        recursorede.lpRemoteName = Caminho
        recursorede.lpLocalName = LetraDrive & ":"
        strUsername = PegaParametro("GERAL", "DSUSUARI")
        strPassword = PegaParametro("GERAL", "DSSENHAX")
        recursorede.dwType = RESOURCETYPE_DISK

        Dim resultado As Integer
        resultado = WNetAddConnection2(recursorede, strPassword, strUsername, 0)

        If resultado = 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function RemoveMapeamentoDrive(ByVal LetraDrive As String) As Boolean
        Dim rc As Integer
        rc = WNetCancelConnection2(LetraDrive & ":", 0, ForceDisconnect)

        If rc = 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    'Sub 'GravaLog
    Public Sub GravaLog(ByVal Mensagem As String)
        If System.IO.File.Exists(NMARQLOG) Then
            ESCRITOR = New System.IO.FileStream(NMARQLOG, IO.FileMode.Append, IO.FileAccess.Write)
        Else
            ESCRITOR = New System.IO.FileStream(NMARQLOG, IO.FileMode.CreateNew, IO.FileAccess.Write)
        End If
        ESCRITORTEXTO = New System.IO.StreamWriter(ESCRITOR)
        ESCRITORTEXTO.WriteLine(Mensagem)
        ESCRITORTEXTO.Close()
    End Sub

    'Funcao Pega Parametro do Arquivo .ini, .txt
    Public Function PegaParametro(ByRef CDSESSAO As String, ByRef CDPARAM As String) As String
        Dim NRTAMPAR As Integer = 0
        Dim DSPARAME As String = New String(Chr(0), 255)
        Dim NMARQINI As String = My.Application.Info.DirectoryPath & "\LimpaCache.ini"

        NRTAMPAR = GetPrivateProfileString(CDSESSAO, CDPARAM, "", DSPARAME, Len(DSPARAME), NMARQINI)
        PegaParametro = Microsoft.VisualBasic.Left(DSPARAME, NRTAMPAR)
        'If NRTAMPAR = Nothing Then
        'End
        'End If
    End Function

    Public Sub VerificaExecucaoPrograma(ByVal NomeAplicativo)
        Try
            Dim processo() As Process = Process.GetProcessesByName(NomeAplicativo)
            If processo.Length > 1 Then
                'GravaLog("Já Existe Uma Instância do Programa Aberto. Finalizando Execução")
                Application.Exit()
            End If
        Catch
            'GravaLog("Erro VerificaExecucaoPrograma : " & Err.Number & Err.Description)
        End Try
    End Sub
    Public Sub ConectaDBAcess()
        Dim NMBANCOX As String
        Dim DSUSUBDX As String
        Dim DSSENBDX As String

        NMBANCOX = PegaParametro("BD", "NMBANCOX")
        DSUSUBDX = PegaParametro("BD", "DSUSUBDX")
        DSSENBDX = PegaParametro("BD", "DSSENBDX")

        Dim CONEXBDX As OleDbConnection = New OleDbConnection()
        CONEXBDX.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & My.Application.Info.DirectoryPath & "\" & NMBANCOX
        CONEXBDX.Open()
    End Sub

    Public Sub ExecutaLimpezaDiretorio(ByVal NMDIRETO)
        Dim TMARQPES As Integer
        INLIMDES = PegaParametro("GERAL", "INLIMDES")
        Try
            If INLIMDES = 1 Then
                'GravaLog("...Iniciando Limpeza do Diretório de Destino...")
                For Each TBARQLIS As String In IO.Directory.GetFiles(NMDIRETO, "*.*", IO.SearchOption.AllDirectories)
                    TMARQPES = TBARQLIS.Length
                    IO.File.Delete(TBARQLIS)
                    'GravaLog("Arquivo Deletado : " & TBARQLIS)
                Next
            End If
        Catch
            'GravaLog("Erro ExecutaLimpezaDiretorio : " & Err.Number & Err.Description)
        End Try
    End Sub

    Public Sub LimpaDiretorio(ByVal NMDIRETO)
        'GravaLog("...Limpeza do Diretório: " & NMDIRETO)
        Try
            For Each TBDIRPES As String In IO.Directory.GetDirectories(NMDIRETO, "*.*", IO.SearchOption.AllDirectories)
                For Each TBARQLIS As String In IO.Directory.GetFiles(TBDIRPES, "*.*", IO.SearchOption.AllDirectories)
                    ExcluiArquivo(TBARQLIS)
                Next
                ExcluiDiretorio(TBDIRPES)
            Next
        Catch
            'GravaLog("Erro LimpaDiretorio : " & Err.Number & Err.Description)
        End Try
    End Sub


    Public Function CopiaArquivo(ByVal AUXORIGX, ByVal AUXDESTX)
        Dim Sucess As Boolean = False
        Try
            IO.File.Copy(AUXORIGX, AUXDESTX, True)
            'GravaLog("...Cópia de Arquivo Após Pesquisa...")
            'GravaLog("Arquivo Copiado de : " & AUXORIGX & " para: " & AUXDESTX)
            Return True
        Catch
            'GravaLog("Erro : " & Err.Number & Err.Description)
            Return False
        End Try
    End Function

    Public Function ExcluiArquivo(ByVal NMARQUIVO)
        Dim Sucess As Boolean = False
        Dim ArquivoFormatado As String = FormataTamanho(NMARQUIVO)
        Try
            IO.File.Delete(NMARQUIVO)
            'GravaLog("Arquivo Deletado : " & ArquivoFormatado)
            Return True
        Catch
            'GravaLog("Erro : " & Err.Number & Err.Description)
            Return False
        End Try
    End Function

    Public Sub ExcluiDiretorio(TBDIRPES As String)
        Throw New NotImplementedException
    End Sub

    Public Sub PesquisaPasta(ByVal NMDIRETO, ByVal EXTNMPES)
        For Each TBARQPES As String In IO.Directory.GetFiles(NMDIRETO, EXTNMPES, IO.SearchOption.AllDirectories)
            AUXORIGX = TBARQPES
            AUXDESTX = NMDESTIN & "\" & IO.Path.GetFileName(TBARQPES)
            If CopiaArquivo(AUXORIGX, AUXDESTX) = True Then
                ExcluiArquivo(TBARQPES)
            Else
                Exit Sub
            End If
        Next
    End Sub

    Public Sub EnviaEmail(ByVal ENDREMEX As String,
                          ByVal ENDDESTX As String,
                          ByVal DSUSUARI As String,
                          ByVal DSSENHAX As String,
                          ByVal ENDSMTPX As String,
                          ByVal DSPORTAX As Integer)
        Dim Mensagem As Net.Mail.MailMessage = New MailMessage(ENDREMEX, ENDDESTX)
        Dim AutenticationCredential As Net.NetworkCredential = New Net.NetworkCredential(DSUSUARI, DSSENHAX)
        Dim ClienteSMTP As Net.Mail.SmtpClient = New Net.Mail.SmtpClient(ENDSMTPX, DSPORTAX)
        Mensagem.IsBodyHtml = True
        'Mensagem.Attachments.Add(New Attachment(My.Application.Info.DirectoryPath & "\LimpaCache" & Date.Now.Year & Date.Now.Month & Date.Now.Day & ".log"))
        Mensagem.Subject = "Programa LimpaCache - Status Report"
        Mensagem.Body = "<P>Bom dia</P>" &
                        "<P><B><FONT COLOR=""#FF0000"">Esta é uma Mensagem Automática. Favor Não Responder.</FONT></B></P>" &
                        "<P>Segue Anexo o Log de Execução do Programa LimpaCache, no Servidor: <B>" & My.Computer.Name & "</B> .Favor analisar o conteúdo do Arquivo" &
                        " e, na constatação de qualquer anomalia comunicar o Suporte - Lince.</P>" &
                        "<BR>" &
                        "<P>Obrigado.</P>"
        ClienteSMTP.EnableSsl = True
        ClienteSMTP.UseDefaultCredentials = False
        ClienteSMTP.Credentials = AutenticationCredential
        Try
            ClienteSMTP.Send(Mensagem)
        Catch ex As Exception
            'GravaLog("Erro : " & Err.Number & " - " & Err.Description)
        End Try
    End Sub

    Public Function FormataTamanho(ByVal NMARQUIVO)
        Dim DSARQPES As IO.FileInfo
        Dim TamanhoFormatadoArquivo As String
        Dim NumeroCerto As Integer
        Try
            DSARQPES = New IO.FileInfo(NMARQUIVO)
            If DSARQPES.Length <= 1 Then
                TamanhoFormatadoArquivo = NMARQUIVO & " - " & DSARQPES.Length & " byte."
                Return TamanhoFormatadoArquivo
            End If
            If DSARQPES.Length > 1 And DSARQPES.Length < 1000 Then
                TamanhoFormatadoArquivo = NMARQUIVO & " - " & DSARQPES.Length & " bytes."
                Return TamanhoFormatadoArquivo
            End If
            If DSARQPES.Length >= 1000 Then
                NumeroCerto = DSARQPES.Length / 1000
                TamanhoFormatadoArquivo = NMARQUIVO & " - " & NumeroCerto & " Megabytes."
                Return TamanhoFormatadoArquivo
            End If
            Return True
        Catch
            'GravaLog("Erro CopiaArquivo : " & Err.Number & Err.Description)
            Return False
        End Try
    End Function

    Public Function FormataNumero(ByVal NUMERO)
        Dim TamanhoFormatadoNumero As String
        Dim NumeroCerto As Integer
        Try

            If NUMERO <= 1 Then
                TamanhoFormatadoNumero = NUMERO & "byte"
                Return TamanhoFormatadoNumero
            End If
            If NUMERO > 1 And NUMERO < 1024 Then
                TamanhoFormatadoNumero = NUMERO & "bytes"
                Return TamanhoFormatadoNumero
            End If
            If NUMERO >= 1000 And NUMERO < 1048576 Then
                TamanhoFormatadoNumero = NUMERO & "MB"
                Return TamanhoFormatadoNumero
            End If
            If NUMERO >= 1073741824 Then
                NumeroCerto = NUMERO / 1024
                NumeroCerto = NumeroCerto / 1024
                NumeroCerto = NumeroCerto / 1024
                TamanhoFormatadoNumero = NumeroCerto & "GB"
                Return TamanhoFormatadoNumero
            End If
            Return True
        Catch
            'GravaLog("Erro FormataNumero : " & Err.Number & Err.Description)
            Return False
        End Try
    End Function

    Public Function GetProductKey(ByVal KeyPath As String, ByVal ValueName As String) As String
        Try
            Dim HexBuf As Object = My.Computer.Registry.GetValue(KeyPath, ValueName, 0)

            If HexBuf Is Nothing Then Return "N/A"

            Dim tmp As String = ""

            For l As Integer = LBound(HexBuf) To UBound(HexBuf)
                tmp = tmp & " " & Hex(HexBuf(l))
            Next

            Dim StartOffset As Integer = 52
            Dim EndOffset As Integer = 67
            Dim Digits(24) As String

            Digits(0) = "B" : Digits(1) = "C" : Digits(2) = "D" : Digits(3) = "F"
            Digits(4) = "G" : Digits(5) = "H" : Digits(6) = "J" : Digits(7) = "K"
            Digits(8) = "M" : Digits(9) = "P" : Digits(10) = "Q" : Digits(11) = "R"
            Digits(12) = "T" : Digits(13) = "V" : Digits(14) = "W" : Digits(15) = "X"
            Digits(16) = "Y" : Digits(17) = "2" : Digits(18) = "3" : Digits(19) = "4"
            Digits(20) = "6" : Digits(21) = "7" : Digits(22) = "8" : Digits(23) = "9"

            Dim dLen As Integer = 29
            Dim sLen As Integer = 15
            Dim HexDigitalPID(15) As String
            Dim Des(30) As String

            Dim tmp2 As String = ""

            For i = StartOffset To EndOffset
                HexDigitalPID(i - StartOffset) = HexBuf(i)
                tmp2 = tmp2 & " " & Hex(HexDigitalPID(i - StartOffset))
            Next

            Dim KEYSTRING As String = ""

            For i As Integer = dLen - 1 To 0 Step -1
                If ((i + 1) Mod 6) = 0 Then
                    Des(i) = "-"
                    KEYSTRING = KEYSTRING & "-"
                Else
                    Dim HN As Integer = 0
                    For N As Integer = (sLen - 1) To 0 Step -1
                        Dim Value As Integer = ((HN * 2 ^ 8) Or HexDigitalPID(N))
                        HexDigitalPID(N) = Value \ 24
                        HN = (Value Mod 24)

                    Next

                    Des(i) = Digits(HN)
                    KEYSTRING = KEYSTRING & Digits(HN)
                End If
            Next

            Return StrReverse(KEYSTRING)
        Catch

        End Try

    End Function

    Public Function DiscosLocaisLIB(ByVal LetraDisco)


        Dim RootPath As String = LetraDisco
        Dim SectorsInCluster As Integer = 0
        Dim BytesInSector As Integer = 0
        Dim NumberFreeClusters = 0
        Dim TotalNumberClusters = 0
        Call Win32API.GetDiskFreeSpace(RootPath, SectorsInCluster, BytesInSector, NumberFreeClusters, TotalNumberClusters)

        'GravaLog("DiscosLocaisLIB", "GetDiskSpace: Cluster livres em" & LetraDisco & NumberFreeClusters)

        Dim FreeBytes As Integer = 0
        Dim TotalBytes As Integer = 0
        Dim TotalFreeBytes As UInt32 = 0
        Call Win32API.GetDiskFreeSpaceEx(RootPath, FreeBytes, TotalBytes, TotalFreeBytes)

        'GravaLog("DiscosLocaisLIB", "GetDiskSpaceEx: Total de bytes livres em " & LetraDisco & TotalFreeBytes)

        Dim DriveType As Integer = Win32API.GetDriveType(RootPath)
        Dim DriveTypeName As String = String.Empty
        Select Case DriveType
            Case 2 : DriveTypeName = "Removível"
            Case 3 : DriveTypeName = "Fixo"
            Case 4 : DriveTypeName = "Remoto"
            Case 5 : DriveTypeName = "CD-Rom"
            Case 6 : DriveTypeName = "RAM Disk"
            Case Else : DriveTypeName = "Desconhecido"
        End Select

        'GravaLog("DiscosLocaisLIB", "GetDriveType: Tipo de Drive : " & DriveTypeName)
        Return True
    End Function

    'Usado atualmente só pra gerar o array de programas instalados
    Public Function ProgramasInstalados()
        Dim SubKey As RegistryKey
        'Abre a chave que consta os programas que possuem desinstalador
        Dim Key As RegistryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", False)
        'Levanta Todos os Programas
        Dim SubKeyNames() As String = Key.GetSubKeyNames()
        'Lista todos os Programas
        For Index = 0 To Key.SubKeyCount - 1
            SubKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" & "\" & SubKeyNames(Index), False)
            'Valida se o Programa tem um Nome Valido para Exibiçao
            If Not SubKey.GetValue("DisplayName", "") Is "" Then
                ArrayProgramasInstalados.Add(CType(SubKey.GetValue("DisplayName", ""), String))
            End If
        Next
        Return True
    End Function
    Public Function MontaComando(ByVal ItemComando As String, Optional ByVal Separador As String = Nothing) As String
        StringComandoColeta += "'" & ItemComando & "'" & Separador
        Return StringComandoColeta
    End Function

    Public Function StringCompletaComando()
        Dim StringCompleta = StringComandoColeta.Remove(StringComandoColeta.Length - 1)
        Return StringCompleta
    End Function

    Public Function DadosAleatorios()
        ProgramasInstalados()
        ArrayNomeHosts.Add("NBBNU008901")
        ArrayNomeHosts.Add("NBBNU003356")
        ArrayNomeHosts.Add("NBBNU005001")
        ArrayNomeHosts.Add("PCBNU009689")
        ArrayNomeHosts.Add("PCBNU007656")
        ArrayNomesUsuarios.Add("Diego.Pamplona")
        ArrayNomesUsuarios.Add("Jose.Santos")
        ArrayNomesUsuarios.Add("Pedro.Santos")
        ArrayNomesUsuarios.Add("Patricia.Lopes")
        ArrayControladorDominio.Add("HONDA")
        ArrayControladorDominio.Add("CIVIC")
        ArrayControladorDominio.Add("UP")
        ArrayModelProcessadores.Add("Intel(R) Core(TM) i7-4532M CPU @ 3.20GHz")
        ArrayModelProcessadores.Add("Intel(R) Core(TM) i3-4323M CPU @ 2.00GHz")
        ArrayModelProcessadores.Add("Intel(R) Core(TM) i7-1278M CPU @ 2.80GHz")
        ArrayModelProcessadores.Add("Intel(R) Core(TM) i5-6730M CPU @ 2.60GHz")
        ArrayModelProcessadores.Add("Intel(R) Core(TM) i3-9813M CPU @ 2.60GHz")
        ArrayQtdCores.Add("8 Cores")
        ArrayQtdCores.Add("6 Cores")
        ArrayQtdCores.Add("4 Cores")
        ArrayVersoesWindows.Add("Microsoft Windows 10 Pro")
        ArrayVersoesWindows.Add("Microsoft Windows 10 Enterprise")
        ArrayVersoesWindows.Add("Microsoft Windows 8.1 Pro")
        ArrayVersoesWindows.Add("Microsoft Windows 7 Professional")
        ArrayVersoesWindows.Add("Microsoft Windows Vista Professional")
        ArrayMemoriaDisponivel.Add("1GB")
        ArrayMemoriaDisponivel.Add("3GB")
        ArrayMemoriaDisponivel.Add("4GB")
        ArrayMemoriaDisponivel.Add("6GB")
        ArrayMemoriaDisponivel.Add("2GB")
        ArrayMemoriaDisponivel.Add("7GB")
        ArrayMemoriaDisponivel.Add("8GB")
        ArrayMemoriaTotal.add("16GB")
        ArrayMemoriaTotal.add("12GB")
        ArrayMemoriaTotal.add("14GB")
        ArrayMemoriaTotal.add("10GB")
        ArrayDiscoTotal.Add("513GB")
        ArrayDiscoTotal.Add("988GB")
        ArrayDiscoTotal.Add("687GB")
        ArrayDiscoTotal.Add("2237GB")
        ArrayDiscoDisponivel.Add("120GB")
        ArrayDiscoDisponivel.Add("320GB")
        ArrayDiscoDisponivel.Add("133GB")
        ArrayDiscoDisponivel.Add("321GB")
        ArrayUptime.Add("0 dias e 12 horas e 03 minutos e 32 segundos")
        ArrayUptime.Add("1 dia e 3 horas e 27 minutos e 12 segundos")
        ArrayUptime.Add("23 dias e 4 horas e 12 minutos e 56 segundos")
        ArrayUptime.Add("0 dias e 4 horas e 56 minutos e 34 segundos")
        ArrayUptime.Add("0 dias e 7 horas e 34 minutos e 02 segundos")
        ArrayUptime.Add("0 dias e 9 horas e 12 minutos e 11 segundos")
        ArrayUptime.Add("0 dias e 2 horas e 33 minutos e 45 segundos")
        Return True
    End Function

    Public Function PopulaDadosAleatoriosColeta()
        StringComandoColeta = Nothing
        DadosAleatorios()
        Dim rnd As Random = New Random
        Dim idxrnd As Integer = 0
        Dim TamanhoArrayProgramas As String = ArrayProgramasInstalados.Count.ToString
        Dim TamanhoArrayUsuarios As String = ArrayNomesUsuarios.Count.ToString
        Dim TamanhoArrayControlDom As String = ArrayControladorDominio.Count.ToString
        Dim TamanhoArrayHosts As String = ArrayNomeHosts.Count.ToString
        Dim TamanhoArrayModelProcessadores As String = ArrayModelProcessadores.Count.ToString
        Dim TamanhoArrayQtdCores As String = ArrayQtdCores.Count.ToString
        Dim TamanhoArrayVersoesWindows As String = ArrayVersoesWindows.Count.ToString
        Dim TamanhoArrayMemoriaDisponivel As String = ArrayMemoriaDisponivel.Count.ToString
        Dim TamanhoArrayMemoriaTotal As String = ArrayMemoriaTotal.Count.ToString
        Dim TamanhoArrayDiscoTotal As String = ArrayDiscoTotal.Count.ToString
        Dim TamanhoArrayDiscoDisponivel As String = ArrayDiscoDisponivel.Count.ToString
        Dim TamanhoArrayUptime As String = ArrayUptime.Count.ToString
        Dim ContaImpressoras As Integer = 0
        Dim ContaProgramas As Integer = 0
        MontaComando(DataHoje, ",")
        MontaComando(HoraAtual, ",")
        'Pega Aleatorio um Nome de Host
        idxrnd = rnd.Next(1, TamanhoArrayHosts)
        MontaComando(ArrayNomeHosts.Item(idxrnd), ",")
        idxrnd = 0
        'Pega Aleatorio um Usuario
        idxrnd = rnd.Next(1, TamanhoArrayUsuarios)
        MontaComando(ArrayNomesUsuarios.Item(idxrnd), ",")
        idxrnd = 0
        'Pega Aleatorio um Controlador Dominio
        idxrnd = rnd.Next(1, TamanhoArrayControlDom)
        MontaComando(ArrayControladorDominio.Item(idxrnd), ",")
        idxrnd = 0
        'Pega Aleatorio um Uptime
        idxrnd = rnd.Next(1, TamanhoArrayUptime)
        MontaComando(ArrayUptime.Item(idxrnd), ",")
        idxrnd = 0
        MontaComando(Computador.TimeZoneAtual, ",")
        'Pega Aleatorio um Processador
        idxrnd = rnd.Next(1, TamanhoArrayModelProcessadores)
        MontaComando(ArrayModelProcessadores.Item(idxrnd), ",")
        idxrnd = 0
        'Pega Aleatorio um Core de Processador
        idxrnd = rnd.Next(1, TamanhoArrayQtdCores)
        MontaComando(ArrayQtdCores(idxrnd), ",")
        idxrnd = 0
        'Pega Aleatorio um Sistema Operacional
        idxrnd = rnd.Next(1, TamanhoArrayVersoesWindows)
        MontaComando(ArrayVersoesWindows(idxrnd), ",")
        idxrnd = 0
        MontaComando(SistemaOperacional.Plataforma, ",")
        MontaComando(SistemaOperacional.Linguagem, ",")
        'Pega Aleatorio uma Tamanho MemoriaFisica Total
        idxrnd = rnd.Next(1, TamanhoArrayMemoriaTotal)
        MontaComando(ArrayMemoriaTotal(idxrnd), ",")
        idxrnd = 0
        'Pega Aleatorio uma Tamanho MemoriaFisica Disponivel
        idxrnd = rnd.Next(1, TamanhoArrayMemoriaDisponivel)
        MontaComando(ArrayMemoriaDisponivel(idxrnd), ",")
        idxrnd = 0
        For Each drive As IO.DriveInfo In My.Computer.FileSystem.Drives
            If drive.IsReady = True And drive.DriveType <> IO.DriveType.CDRom Then
                MontaComando(DiscosLocais.Nome(drive.ToString), ",")
                MontaComando(DiscosLocais.Formato(drive.ToString), ",")
                'Pega Aleatorio uma Tamanho DiscoTotal Disponivel
                idxrnd = rnd.Next(1, TamanhoArrayDiscoTotal)
                MontaComando(ArrayDiscoTotal(idxrnd), ",")
                idxrnd = 0
                'Pega Aleatorio uma Tamanho DiscoTotal Disponivel
                idxrnd = rnd.Next(1, TamanhoArrayDiscoDisponivel)
                MontaComando(ArrayDiscoDisponivel(idxrnd), ",")
                idxrnd = 0
            End If
        Next drive
        If NetworkInterface.GetIsNetworkAvailable Then
            ' Obtem e define todos os objetos NetworkInterface para a maquina local
            Dim interfaces As NetworkInterface() = NetworkInterface.GetAllNetworkInterfaces()
            ' Percorre as interfaces
            For Each ni As NetworkInterface In interfaces
                If ni.Name = "Conexão local" Or ni.Name = "Conexão de Rede sem Fio" Then
                    MontaComando(ni.Name, ",")
                    MontaComando(ni.Description, ",")
                    MontaComando(ni.GetPhysicalAddress().ToString(), ",")
                    For Each addr As UnicastIPAddressInformation In ni.GetIPProperties.UnicastAddresses
                        If addr.Address.ToString.Contains(":") Then
                        Else
                            MontaComando(addr.Address.ToString, ",")
                        End If
                    Next
                End If
            Next
        End If
        MontaComando(Monitor.PlacaVideo, ",")
        MontaComando(Monitor.ResolucaoTelaAtual, ",")
        For Each pkInstalledPrinters In PrinterSettings.InstalledPrinters
            ContaImpressoras += 1
            MontaComando(pkInstalledPrinters.ToString, ",")
        Next pkInstalledPrinters
        MontaComando(ProdutosMicrosoft.ChaveWindows, ",")
        MontaComando(ProdutosMicrosoft.ChaveOffice, ",")
        MontaComando(SQLServer.PegaNomeSQLServer().Replace("\", ""), ",")

        'Monta um arranjo de programas instalados com o array padrao
        For idx = 0 To ArrayProgramasInstalados.Count - 1
            idxrnd = rnd.Next(1, TamanhoArrayProgramas)
            MontaComando(ArrayProgramasInstalados.Item(idxrnd), ",")
        Next
        ArrayProgramasInstalados.Clear()
        ArrayControladorDominio.Clear()
        ArrayNomeHosts.Clear()
        ArrayNomesUsuarios.Clear()
        ArrayModelProcessadores.Clear()
        ArrayQtdCores.Clear()
        ArrayVersoesWindows.Clear()
        ArrayMemoriaDisponivel.Clear()
        ArrayMemoriaTotal.Clear()
        ArrayDiscoTotal.Clear()
        ArrayDiscoDisponivel.Clear()
        ArrayUptime.Clear()
        StringComandoColeta = StringComandoColeta.Remove(StringComandoColeta.Length - 1)
        ExecutaComando("Insert into Coletas (datacoleta,horacoleta,nmhost,nmuserlogado,nmcontdomhost,uptimehost,timezonehost,prochost,qtdcorhost,nmsoatualhost,platsoatualhost,lingsoatualhost,qtdmemhost,qtdmemdisphost,discosohost,formatdiscosohost,tamtotdiscosohost,tamdispdiscosohost,nomeniccabo,descniccabo,macaddressniccabo,enderipniccabo,nomenicsemfio,descnicsemfio,macaddressnicsemfio,enderipnicsemfio,placavideo,resolucaoatual,impressorainst1,impressorainst2,impressorainst3,impressorainst4,impressorainst5,impressorainst6,impressorainst7,chavewindows,chaveoffice,instanciasql,programinstal1,programinstal2,programinstal3,programinstal4,programinstal5,programinstal6,programinstal7,programinstal8,programinstal9,programinstal10,programinstal11,programinstal12,programinstal13,programinstal14,programinstal15,programinstal16,programinstal17,programinstal18,programinstal19,programinstal20,programinstal21,programinstal22,programinstal23,programinstal24,programinstal25,programinstal26,programinstal27,programinstal28,programinstal29,programinstal30,programinstal31,programinstal32,programinstal33,programinstal34,programinstal35,programinstal36,programinstal37,programinstal38,programinstal39,programinstal40,programinstal41,programinstal42,programinstal43,programinstal44,programinstal45,programinstal46,programinstal47,programinstal48,programinstal49,programinstal50,programinstal51,programinstal52,programinstal53,programinstal54,programinstal55,programinstal56,programinstal57,programinstal58,programinstal59,programinstal60,programinstal61,programinstal62,programinstal63,programinstal64,programinstal65,programinstal66,programinstal67,programinstal68,programinstal69,programinstal70,programinstal71,programinstal72,programinstal73,programinstal74,programinstal75,programinstal76,programinstal77,programinstal78,programinstal79,programinstal80,programinstal81,programinstal82,programinstal83,programinstal84,programinstal85,programinstal86,programinstal87,programinstal88,programinstal89,programinstal90,programinstal91,programinstal92,programinstal93,programinstal94) values (" & StringComandoColeta & ")")
        Return StringComandoColeta
    End Function

    Public Function ExecutaColeta()
        StringComandoColeta = Nothing
        MontaComando(DataHoje, ",")
        MontaComando(HoraAtual, ",")
        MontaComando(Computador.Nome, ",")
        MontaComando(Computador.UsuarioAtual, ",")
        MontaComando(Computador.ControladorDominio, ",")
        MontaComando(Computador.Uptime, ",")
        MontaComando(Computador.TimeZoneAtual, ",")
        MontaComando(Processador.Nome, ",")
        MontaComando(Processador.Core, ",")
        MontaComando(SistemaOperacional.Nome, ",")
        MontaComando(SistemaOperacional.Plataforma, ",")
        MontaComando(SistemaOperacional.Linguagem, ",")
        MontaComando(Memoria.MemoriaFisicaTotal, ",")
        MontaComando(Memoria.MemoriaFisicaTotal, ",")
        For Each drive As IO.DriveInfo In My.Computer.FileSystem.Drives
            If drive.IsReady = True And drive.DriveType <> IO.DriveType.CDRom Then
                MontaComando(DiscosLocais.Nome(drive.ToString), ",")
                MontaComando(DiscosLocais.Formato(drive.ToString), ",")
                MontaComando(DiscosLocais.TamanhoTotal(drive.ToString), ",")
                MontaComando(DiscosLocais.TamanhoDisponivel(drive.ToString), ",")
            End If
        Next drive
        If NetworkInterface.GetIsNetworkAvailable Then

            Dim interfaces As NetworkInterface() = NetworkInterface.GetAllNetworkInterfaces()
            For Each ni As NetworkInterface In interfaces
                If ni.Name = "Conexão local" Or ni.Name = "Conexão de Rede sem Fio" Then
                    MontaComando(ni.Name, ",")
                    MontaComando(ni.Description, ",")
                    MontaComando(ni.GetPhysicalAddress().ToString(), ",")
                    For Each addr As UnicastIPAddressInformation In ni.GetIPProperties.UnicastAddresses
                        If addr.Address.ToString.Contains(":") Then
                        Else
                            MontaComando(addr.Address.ToString, ",")
                        End If
                    Next
                End If
            Next
        End If
        MontaComando(Monitor.PlacaVideo, ",")
        MontaComando(Monitor.ResolucaoTelaAtual, ",")
        For Each pkInstalledPrinters In PrinterSettings.InstalledPrinters
            MontaComando(pkInstalledPrinters.ToString, ",")
        Next pkInstalledPrinters
        MontaComando(ProdutosMicrosoft.ChaveWindows, ",")
        MontaComando(ProdutosMicrosoft.ChaveOffice, ",")
        MontaComando(SQLServer.PegaNomeSQLServer().Replace("\", ""), ",")
        Dim SubKey As RegistryKey
        'Abre a chave que consta os programas que possuem desinstalador
        Dim Key As RegistryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", False)
        'Levanta Todos os Programas
        Dim SubKeyNames() As String = Key.GetSubKeyNames()
        'Lista todos os Programas
        For Index = 0 To Key.SubKeyCount - 1
            SubKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" & "\" & SubKeyNames(Index), False)
            'Valida se o Programa tem um Nome Valido para Exibiçao
            If Not SubKey.GetValue("DisplayName", "") Is "" Then
                MontaComando((CType(SubKey.GetValue("DisplayName", ""), String)), ",")
            End If
        Next
        StringComandoColeta = StringComandoColeta.Remove(StringComandoColeta.Length - 1)
        GravaLog(StringComandoColeta)
        ExecutaComando("Insert into Coletas (datacoleta,horacoleta,nmhost,nmuserlogado,nmcontdomhost,uptimehost,timezonehost,prochost,qtdcorhost,nmsoatualhost,platsoatualhost,lingsoatualhost,qtdmemhost,qtdmemdisphost,discosohost,formatdiscosohost,tamtotdiscosohost,tamdispdiscosohost,nomeniccabo,descniccabo,macaddressniccabo,enderipniccabo,nomenicsemfio,descnicsemfio,macaddressnicsemfio,enderipnicsemfio,placavideo,resolucaoatual,impressorainst1,impressorainst2,impressorainst3,impressorainst4,impressorainst5,impressorainst6,impressorainst7,chavewindows,chaveoffice,instanciasql,programinstal1,programinstal2,programinstal3,programinstal4,programinstal5,programinstal6,programinstal7,programinstal8,programinstal9,programinstal10,programinstal11,programinstal12,programinstal13,programinstal14,programinstal15,programinstal16,programinstal17,programinstal18,programinstal19,programinstal20,programinstal21,programinstal22,programinstal23,programinstal24,programinstal25,programinstal26,programinstal27,programinstal28,programinstal29,programinstal30,programinstal31,programinstal32,programinstal33,programinstal34,programinstal35,programinstal36,programinstal37,programinstal38,programinstal39,programinstal40,programinstal41,programinstal42,programinstal43,programinstal44,programinstal45,programinstal46,programinstal47,programinstal48,programinstal49,programinstal50,programinstal51,programinstal52,programinstal53,programinstal54,programinstal55,programinstal56,programinstal57,programinstal58,programinstal59,programinstal60,programinstal61,programinstal62,programinstal63,programinstal64,programinstal65,programinstal66,programinstal67,programinstal68,programinstal69,programinstal70,programinstal71,programinstal72,programinstal73,programinstal74,programinstal75,programinstal76,programinstal77,programinstal78,programinstal79,programinstal80,programinstal81,programinstal82,programinstal83,programinstal84,programinstal85,programinstal86,programinstal87,programinstal88,programinstal89,programinstal90,programinstal91,programinstal92,programinstal93,programinstal94) values (" & StringComandoColeta & ")")
        Return StringComandoColeta
    End Function
    Public Function CriaXML()
        Dim ContaImpressoras As Integer = 0
        Dim ContaProgramas As Integer = 0
        MontaComando(DataHoje, ",")
        MontaComando(HoraAtual, ",")
        Dim xmlPath As String = "c:\temp\" & Date.Now.Year & Date.Now.Month & Date.Now.Day & Date.Now.Hour & Date.Now.Minute & Date.Now.Second & ".xml"
        ' Cria um novo ficheiro XML com a codificação UTF8
        Dim xmlw As New XmlTextWriter(xmlPath, System.Text.Encoding.UTF8)
        xmlw.Formatting = Formatting.Indented

        xmlw.WriteStartDocument()

        ' Adiciona um comentário geral
        xmlw.WriteComment("Declaracao do Node Pai")

        ' Criar um elemento geral
        xmlw.WriteStartElement("AuditCo_Cliente")

        ' Criar o Node Filho "Computador" e alguns dados
        With xmlw
            ' Adiciona um comentário Identificador Node Filho
            xmlw.WriteComment("Declaracao do Node Filho Computador")
            .WriteStartElement("Computador")
            .WriteElementString("Nome", Computador.Nome)
            MontaComando(Computador.Nome, ",")
            .WriteElementString("Usuario", Computador.UsuarioAtual)
            MontaComando(Computador.UsuarioAtual, ",")
            .WriteElementString("ControladorDominio", Computador.ControladorDominio)
            MontaComando(Computador.ControladorDominio, ",")
            .WriteElementString("Uptime", Computador.Uptime)
            MontaComando(Computador.Uptime, ",")
            .WriteElementString("TimeZone", Computador.TimeZoneAtual)
            MontaComando(Computador.TimeZoneAtual, ",")
            .WriteEndElement()
        End With

        ' Criar o Node Filho "Processador" e alguns dados
        With xmlw
            ' Adiciona um comentário Identificador Node Filho
            xmlw.WriteComment("Declaracao do Node Filho Processador")
            .WriteStartElement("Processador")
            .WriteElementString("Nome", Processador.Nome)
            MontaComando(Processador.Nome, ",")
            .WriteElementString("Cores", Processador.Core)
            MontaComando(Processador.Core, ",")
            .WriteEndElement()
        End With

        ' Criar o Node Filho "Informacoes SO" e alguns dados
        With xmlw
            ' Adiciona um comentário Identificador Node Filho
            xmlw.WriteComment("Declaracao do Node Filho Informações do Sistema Operacional")
            .WriteStartElement("Informacoes_SO")
            .WriteElementString("NomeCompleto", SistemaOperacional.Nome())
            MontaComando(SistemaOperacional.Nome, ",")
            '.WriteElementString("Versao", SistemaOperacional.ServicePack())
            'MontaComando(SistemaOperacional.ServicePack, ",")
            .WriteElementString("Plataforma", SistemaOperacional.Plataforma())
            MontaComando(SistemaOperacional.Plataforma, ",")
            .WriteElementString("Linguagem", SistemaOperacional.Linguagem())
            MontaComando(SistemaOperacional.Linguagem, ",")
            .WriteEndElement()
        End With

        ' Criar o Node Filho "Memoria" e alguns dados
        With xmlw
            ' Adiciona um comentário Identificador Node Filho
            xmlw.WriteComment("Declaracao do Node Filho Memoria")
            .WriteStartElement("Memoria")
            .WriteElementString("MemoriaTotal", Memoria.MemoriaFisicaTotal)
            MontaComando(Memoria.MemoriaFisicaTotal, ",")
            .WriteElementString("MemoriaDisponivel", Memoria.MemoriaFisicaDisponivel())
            MontaComando(Memoria.MemoriaFisicaTotal, ",")
            ' Dim TamanhoPente
            ' Dim WmiSelect As New ManagementObjectSearcher("root\CIMV2", "Select * from Win32_MemoryDevice")
            ' For Each WmiResults As ManagementObject In WmiSelect.Get()
            ' TamanhoPente = FormataNumero(WmiResults.GetPropertyValue("EndingAddress"))
            '.WriteElementString("PenteInstalado", TamanhoPente)
            'Next
            .WriteEndElement()
        End With

        ' Criar o Node Filho "DiscosLocais" e alguns dados
        With xmlw
            ' Adiciona um comentário Identificador Node Filho
            xmlw.WriteComment("Declaracao do Node Filho DiscosLocais")
            .WriteStartElement("DiscosLocais")
            For Each drive As IO.DriveInfo In My.Computer.FileSystem.Drives
                If drive.IsReady = True And drive.DriveType <> IO.DriveType.CDRom Then
                    .WriteElementString("Nome", DiscosLocais.Nome(drive.ToString))
                    MontaComando(DiscosLocais.Nome(drive.ToString), ",")
                    .WriteElementString("Formato", DiscosLocais.Formato(drive.ToString))
                    MontaComando(DiscosLocais.Formato(drive.ToString), ",")
                    .WriteElementString("TamanhoTotal", DiscosLocais.TamanhoTotal(drive.ToString))
                    MontaComando(DiscosLocais.TamanhoTotal(drive.ToString), ",")
                    .WriteElementString("TamanhoLivre", DiscosLocais.TamanhoDisponivel(drive.ToString))
                    MontaComando(DiscosLocais.TamanhoDisponivel(drive.ToString), ",")
                End If
                'If drive.DriveType = IO.DriveType.CDRom Then
                '.WriteElementString("Nome", DiscosLocais.Nome(drive.ToString))
                '   .WriteElementString("Rotulo", DiscosLocais.Rotulo(drive.ToString))
                '.WriteElementString("Tipo", DiscosLocais.Tipo(drive.ToString))
                ' .WriteElementString("Formato", DiscosLocais.Formato(drive.ToString))
                'End If
            Next drive
            .WriteEndElement()
        End With

        ' Criar o Node Filho "Rede" e alguns dados
        With xmlw
            ' Adiciona um comentário Identificador Node Filho
            xmlw.WriteComment("Declaracao do Node Filho Rede")
            .WriteStartElement("Rede")
            If NetworkInterface.GetIsNetworkAvailable Then
                ' Obtem e define todos os objetos NetworkInterface para a maquina local
                Dim interfaces As NetworkInterface() = NetworkInterface.GetAllNetworkInterfaces()
                ' Percorre as interfaces
                For Each ni As NetworkInterface In interfaces
                    If ni.Name = "Conexão local" Or ni.Name = "Conexão de Rede sem Fio" Then
                        .WriteElementString("Nome", ni.Name)
                        MontaComando(ni.Name, ",")
                        .WriteElementString("Descricao", ni.Description)
                        MontaComando(ni.Description, ",")
                        .WriteElementString("MacAddress", ni.GetPhysicalAddress().ToString())
                        MontaComando(ni.GetPhysicalAddress().ToString(), ",")
                        For Each addr As UnicastIPAddressInformation In ni.GetIPProperties.UnicastAddresses
                            If addr.Address.ToString.Contains(":") Then
                            Else
                                .WriteElementString("EnderecoIP", addr.Address.ToString)
                                MontaComando(addr.Address.ToString, ",")
                            End If
                        Next
                    End If
                Next
            End If
            .WriteEndElement()
        End With

        ' Criar o Node Filho "Monitor" e alguns dados
        With xmlw
            ' Adiciona um comentário Identificador Node Filho
            xmlw.WriteComment("Declaracao do Node Filho Monitor")
            .WriteStartElement("Monitor")
            .WriteElementString("PlacaVideo", Monitor.PlacaVideo)
            MontaComando(Monitor.PlacaVideo, ",")
            .WriteElementString("ResolucaoAtual", Monitor.ResolucaoTelaAtual)
            MontaComando(Monitor.ResolucaoTelaAtual, ",")
            Dim ResolucaoPossivel As String = String.Empty
            'Dim WmiSelect As New ManagementObjectSearcher("root\CIMV2", "Select * from CIM_VideoControllerResolution")
            'For Each WmiResults As ManagementObject In WmiSelect.Get()
            'ResolucaoPossivel = WmiResults.GetPropertyValue("SettingID").ToString
            '.WriteElementString("ResolucaoPossivel", ResolucaoPossivel)
            'Next
            .WriteEndElement()
        End With

        ' Criar o Node Filho "Printers" e alguns dados
        With xmlw
            ' Adiciona um comentário Identificador Node Filho
            xmlw.WriteComment("Declaracao do Node Filho Impressoras")
            .WriteStartElement("Impressoras")
            ' Find all printers installed
            For Each pkInstalledPrinters In PrinterSettings.InstalledPrinters
                .WriteElementString("Impressora", pkInstalledPrinters.ToString)
                ContaImpressoras += 1
                MontaComando(pkInstalledPrinters.ToString, ",")
            Next pkInstalledPrinters
            .WriteEndElement()
        End With

        ' Criar o Node Filho "Produtos Microsoft" e alguns dados
        With xmlw
            ' Adiciona um comentário Identificador Node Filho
            xmlw.WriteComment("Declaracao do Node Filho Produtos Microsoft")
            .WriteStartElement("ProdutosMicrosoft")
            .WriteElementString("Windows", ProdutosMicrosoft.ChaveWindows)
            MontaComando(ProdutosMicrosoft.ChaveWindows, ",")
            .WriteElementString("Office", ProdutosMicrosoft.ChaveOffice)
            MontaComando(ProdutosMicrosoft.ChaveOffice, ",")
            .WriteElementString("InstanciaSQL", SQLServer.PegaNomeSQLServer().Replace("\", ""))
            MontaComando(SQLServer.PegaNomeSQLServer().Replace("\", ""), ",")
            .WriteEndElement()
        End With

        ' Criar o Node Filho "ProgramasInstalados" e alguns dados
        With xmlw
            ' Adiciona um comentário Identificador Node Filho
            xmlw.WriteComment("Declaracao do Node Filho Programas Instalados")
            .WriteStartElement("ProgramasInstalados")
            Dim SubKey As RegistryKey
            'Abre a chave que consta os programas que possuem desinstalador
            Dim Key As RegistryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", False)
            'Levanta Todos os Programas
            Dim SubKeyNames() As String = Key.GetSubKeyNames()
            'Lista todos os Programas
            For Index = 0 To Key.SubKeyCount - 1
                SubKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" & "\" & SubKeyNames(Index), False)
                'Valida se o Programa tem um Nome Valido para Exibiçao
                If Not SubKey.GetValue("DisplayName", "") Is "" Then
                    ContaProgramas += 1
                    .WriteElementString("ProgramaInstalado", (CType(SubKey.GetValue("DisplayName", ""), String)))
                    MontaComando((CType(SubKey.GetValue("DisplayName", ""), String)), ",")
                End If
            Next
            .WriteEndElement()
        End With



        xmlw.WriteEndElement() ' Insere Final XML Pai
        xmlw.WriteEndDocument()

        ' Fecha o documento XML
        xmlw.Flush()
        xmlw.Close()
        'GravaLog("Informacoes", "Impresssoras Encontradas: " & ContaImpressoras & vbNewLine & "Programas Instalados: " & ContaProgramas & vbNewLine)
        Return True
    End Function

    Public Function carregaTreeView(ByVal arquivoXML As String, ByVal ObjArvore As TreeView)

        ' ----- carrega o documento XML em um objeto XMLDocument
        Try
            conteudoArquivo.Load(arquivoXML)
        Catch ex As Exception
            MsgBox("O documento XML não pode ser carregado pois ocorreu o seguinte erro : " & vbCrLf & vbCrLf & ex.Message)
            conteudoArquivo = Nothing
        End Try

        ' ----- Remove o conteudo do controle TreeView.
        ObjArvore.Nodes.Clear()

        ' ----- Chama o metodo recursivamente que irá percorrer
        '       todos os ramos do arquivo XML.
        For Each No As Xml.XmlNode In conteudoArquivo.ChildNodes
            incluiNonaArvore(No, Nothing, ObjArvore)
        Next No
        Return True
    End Function
    Public Function incluiNonaArvore(ByVal No As Xml.XmlNode, ByVal doNo As TreeNode, ByVal ObjArvore As TreeView)
        ' ----- Inclui um Nó e todos os seus itens subordinados
        Dim noBase As TreeNode

        ' ----- Ignora texto dos Nos, quando ele são marcados
        If (No.NodeType = Xml.XmlNodeType.Text) Then Return 0

        ' ----- Trata a tag  "<?xml…" de forma especial
        If (No.NodeType = Xml.XmlNodeType.XmlDeclaration) And (doNo Is Nothing) Then
            noBase = ObjArvore.Nodes.Add(No.OuterXml.ToString())

        End If

        ' ----- Inclui um No nele mesmo
        If (doNo Is Nothing) Then
            noBase = ObjArvore.Nodes.Add(No.Name)
        Else
            noBase = doNo.Nodes.Add(No.Name)
        End If

        ' ----- Inclui atributos
        If (No.Attributes IsNot Nothing) Then
            For Each atributo As Xml.XmlAttribute In No.Attributes
                noBase.Nodes.Add("Atributo: " & atributo.Name & " = """ & atributo.Value & """")
            Next atributo
        End If

        ' ----- Inclui um conteudo
        If (No.InnerText <> "") Then
            noBase.Nodes.Add("Conteúdo : " & No.InnerText)
        End If

        ' ----- Inclui Nós filhos
        If (No.ChildNodes IsNot Nothing) Then
            For Each subNode As Xml.XmlNode In No.ChildNodes
                incluiNonaArvore(subNode, noBase, ObjArvore)
            Next subNode
        End If
        Return True
    End Function

    Public Function ImportaXMLtoBD(ByVal arquivoXML As String)
        StringComandoColeta = Nothing
        Dim ds As New DataSet
        Dim xmlFile As XmlReader
        Dim ComandoImportacao As String = Nothing
        Dim datacoleta As String = Nothing
        Dim horacoleta As String = Nothing
        Dim nmhost As String = Nothing
        Dim nmuserlogado As String = Nothing
        Dim nmcontdomhost As String = Nothing
        Dim uptimehost As String = Nothing
        Dim timezonehost As String = Nothing
        Dim prochost As String = Nothing
        Dim qtdcorhost As String = Nothing
        Dim nmsoatualhost As String = Nothing
        Dim platsoatualhost As String = Nothing
        Dim lingsoatualhost As String = Nothing
        Dim qtdmemhost As String = Nothing
        Dim qtdmemdisphost As String = Nothing
        Dim discosohost As String = Nothing
        Dim formatdiscosohost As String = Nothing
        Dim tamtotdiscosohost As String = Nothing
        Dim tamdispdiscosohost As String = Nothing
        Dim nomeniccabo As String = Nothing
        Dim descniccabo As String = Nothing
        Dim macaddressniccabo As String = Nothing
        Dim enderipniccabo As String = Nothing
        Dim nomenicsemfio As String = Nothing
        Dim descnicsemfio As String = Nothing
        Dim macaddressnicsemfio As String = Nothing
        Dim enderipnicsemfio As String = Nothing
        Dim placavideo As String = Nothing
        Dim resolucaoatual As String = Nothing
        Dim impressorainst1 As String = Nothing
        Dim impressorainst2 As String = Nothing
        Dim impressorainst3 As String = Nothing
        Dim impressorainst4 As String = Nothing
        Dim impressorainst5 As String = Nothing
        Dim impressorainst6 As String = Nothing
        Dim impressorainst7 As String = Nothing
        Dim chavewindows As String = Nothing
        Dim chaveoffice As String = Nothing
        Dim instanciasql As String = Nothing
        Dim programinstal1 As String = Nothing
        Dim programinstal2 As String = Nothing
        Dim programinstal3 As String = Nothing
        Dim programinstal4 As String = Nothing
        Dim programinstal5 As String = Nothing
        Dim programinstal6 As String = Nothing
        Dim programinstal7 As String = Nothing
        Dim programinstal8 As String = Nothing
        Dim programinstal9 As String = Nothing
        Dim programinstal10 As String = Nothing
        Dim programinstal11 As String = Nothing
        Dim programinstal12 As String = Nothing
        Dim programinstal13 As String = Nothing
        Dim programinstal14 As String = Nothing
        Dim programinstal15 As String = Nothing
        Dim programinstal16 As String = Nothing
        Dim programinstal17 As String = Nothing
        Dim programinstal18 As String = Nothing
        Dim programinstal19 As String = Nothing
        Dim programinstal20 As String = Nothing
        Dim programinstal21 As String = Nothing
        Dim programinstal22 As String = Nothing
        Dim programinstal23 As String = Nothing
        Dim programinstal24 As String = Nothing
        Dim programinstal25 As String = Nothing
        Dim programinstal26 As String = Nothing
        Dim programinstal27 As String = Nothing
        Dim programinstal28 As String = Nothing
        Dim programinstal29 As String = Nothing
        Dim programinstal30 As String = Nothing
        Dim programinstal31 As String = Nothing
        Dim programinstal32 As String = Nothing
        Dim programinstal33 As String = Nothing
        Dim programinstal34 As String = Nothing
        Dim programinstal35 As String = Nothing
        Dim programinstal36 As String = Nothing
        Dim programinstal37 As String = Nothing
        Dim programinstal38 As String = Nothing
        Dim programinstal39 As String = Nothing
        Dim programinstal40 As String = Nothing
        Dim programinstal41 As String = Nothing
        Dim programinstal42 As String = Nothing
        Dim programinstal43 As String = Nothing
        Dim programinstal44 As String = Nothing
        Dim programinstal45 As String = Nothing
        Dim programinstal46 As String = Nothing
        Dim programinstal47 As String = Nothing
        Dim programinstal48 As String = Nothing
        Dim programinstal49 As String = Nothing
        Dim programinstal50 As String = Nothing
        Dim programinstal51 As String = Nothing
        Dim programinstal52 As String = Nothing
        Dim programinstal53 As String = Nothing
        Dim programinstal54 As String = Nothing
        Dim programinstal55 As String = Nothing
        Dim programinstal56 As String = Nothing
        Dim programinstal57 As String = Nothing
        Dim programinstal58 As String = Nothing
        Dim programinstal59 As String = Nothing
        Dim programinstal60 As String = Nothing
        Dim programinstal61 As String = Nothing
        Dim programinstal62 As String = Nothing
        Dim programinstal63 As String = Nothing
        Dim programinstal64 As String = Nothing
        Dim programinstal65 As String = Nothing
        Dim programinstal66 As String = Nothing
        Dim programinstal67 As String = Nothing
        Dim programinstal68 As String = Nothing
        Dim programinstal69 As String = Nothing
        Dim programinstal70 As String = Nothing
        Dim programinstal71 As String = Nothing
        Dim programinstal72 As String = Nothing
        Dim programinstal73 As String = Nothing
        Dim programinstal74 As String = Nothing
        Dim programinstal75 As String = Nothing
        Dim programinstal76 As String = Nothing
        Dim programinstal77 As String = Nothing
        Dim programinstal78 As String = Nothing
        Dim programinstal79 As String = Nothing
        Dim programinstal80 As String = Nothing
        Dim programinstal81 As String = Nothing
        Dim programinstal82 As String = Nothing
        Dim programinstal83 As String = Nothing
        Dim programinstal84 As String = Nothing
        Dim programinstal85 As String = Nothing
        Dim programinstal86 As String = Nothing
        Dim programinstal87 As String = Nothing
        Dim programinstal88 As String = Nothing
        Dim programinstal89 As String = Nothing
        Dim programinstal90 As String = Nothing
        Dim programinstal91 As String = Nothing
        Dim programinstal92 As String = Nothing
        Dim programinstal93 As String = Nothing
        Dim programinstal94 As String = Nothing


        xmlFile = XmlReader.Create(arquivoXML, New XmlReaderSettings())
        ds.ReadXml(xmlFile)
        Dim i As Integer
        For i = 0 To ds.Tables(0).Rows.Count - 1
            datacoleta = ds.Tables(0).Rows(i).Item(0)
            horacoleta = ds.Tables(0).Rows(i).Item(1)
            nmhost = ds.Tables(0).Rows(i).Item(2)
            nmuserlogado = ds.Tables(0).Rows(i).Item(3)
            nmcontdomhost = ds.Tables(0).Rows(i).Item(4)
            uptimehost = ds.Tables(0).Rows(i).Item(5)
            timezonehost = ds.Tables(0).Rows(i).Item(6)
            prochost = ds.Tables(0).Rows(i).Item(7)
            qtdcorhost = ds.Tables(0).Rows(i).Item(8)
            nmsoatualhost = ds.Tables(0).Rows(i).Item(9)
            platsoatualhost = ds.Tables(0).Rows(i).Item(10)
            lingsoatualhost = ds.Tables(0).Rows(i).Item(11)
            qtdmemhost = ds.Tables(0).Rows(i).Item(12)
            qtdmemdisphost = ds.Tables(0).Rows(i).Item(13)
            discosohost = ds.Tables(0).Rows(i).Item(14)
            formatdiscosohost = ds.Tables(0).Rows(i).Item(15)
            tamtotdiscosohost = ds.Tables(0).Rows(i).Item(16)
            tamdispdiscosohost = ds.Tables(0).Rows(i).Item(17)
            nomeniccabo = ds.Tables(0).Rows(i).Item(18)
            descniccabo = ds.Tables(0).Rows(i).Item(19)
            macaddressniccabo = ds.Tables(0).Rows(i).Item(20)
            enderipniccabo = ds.Tables(0).Rows(i).Item(21)
            nomenicsemfio = ds.Tables(0).Rows(i).Item(22)
            descnicsemfio = ds.Tables(0).Rows(i).Item(23)
            macaddressnicsemfio = ds.Tables(0).Rows(i).Item(24)
            enderipnicsemfio = ds.Tables(0).Rows(i).Item(25)
            placavideo = ds.Tables(0).Rows(i).Item(26)
            resolucaoatual = ds.Tables(0).Rows(i).Item(27)
            impressorainst1 = ds.Tables(0).Rows(i).Item(28)
            impressorainst2 = ds.Tables(0).Rows(i).Item(29)
            impressorainst3 = ds.Tables(0).Rows(i).Item(30)
            impressorainst4 = ds.Tables(0).Rows(i).Item(31)
            impressorainst5 = ds.Tables(0).Rows(i).Item(32)
            impressorainst6 = ds.Tables(0).Rows(i).Item(33)
            impressorainst7 = ds.Tables(0).Rows(i).Item(34)
            chavewindows = ds.Tables(0).Rows(i).Item(35)
            chaveoffice = ds.Tables(0).Rows(i).Item(36)
            instanciasql = ds.Tables(0).Rows(i).Item(37)
            programinstal1 = ds.Tables(0).Rows(i).Item(38)
            programinstal2 = ds.Tables(0).Rows(i).Item(39)
            programinstal3 = ds.Tables(0).Rows(i).Item(40)
            programinstal4 = ds.Tables(0).Rows(i).Item(41)
            programinstal5 = ds.Tables(0).Rows(i).Item(42)
            programinstal6 = ds.Tables(0).Rows(i).Item(43)
            programinstal7 = ds.Tables(0).Rows(i).Item(44)
            programinstal8 = ds.Tables(0).Rows(i).Item(45)
            programinstal9 = ds.Tables(0).Rows(i).Item(46)
            programinstal10 = ds.Tables(0).Rows(i).Item(47)
            programinstal11 = ds.Tables(0).Rows(i).Item(48)
            programinstal12 = ds.Tables(0).Rows(i).Item(49)
            programinstal13 = ds.Tables(0).Rows(i).Item(50)
            programinstal14 = ds.Tables(0).Rows(i).Item(51)
            programinstal15 = ds.Tables(0).Rows(i).Item(52)
            programinstal16 = ds.Tables(0).Rows(i).Item(53)
            programinstal17 = ds.Tables(0).Rows(i).Item(54)
            programinstal18 = ds.Tables(0).Rows(i).Item(55)
            programinstal19 = ds.Tables(0).Rows(i).Item(56)
            programinstal20 = ds.Tables(0).Rows(i).Item(57)
            programinstal21 = ds.Tables(0).Rows(i).Item(58)
            programinstal22 = ds.Tables(0).Rows(i).Item(59)
            programinstal23 = ds.Tables(0).Rows(i).Item(60)
            programinstal24 = ds.Tables(0).Rows(i).Item(61)
            programinstal25 = ds.Tables(0).Rows(i).Item(62)
            programinstal26 = ds.Tables(0).Rows(i).Item(63)
            programinstal27 = ds.Tables(0).Rows(i).Item(64)
            programinstal28 = ds.Tables(0).Rows(i).Item(65)
            programinstal29 = ds.Tables(0).Rows(i).Item(66)
            programinstal30 = ds.Tables(0).Rows(i).Item(67)
            programinstal31 = ds.Tables(0).Rows(i).Item(68)
            programinstal32 = ds.Tables(0).Rows(i).Item(69)
            programinstal33 = ds.Tables(0).Rows(i).Item(70)
            programinstal34 = ds.Tables(0).Rows(i).Item(71)
            programinstal35 = ds.Tables(0).Rows(i).Item(72)
            programinstal36 = ds.Tables(0).Rows(i).Item(73)
            programinstal37 = ds.Tables(0).Rows(i).Item(74)
            programinstal38 = ds.Tables(0).Rows(i).Item(75)
            programinstal39 = ds.Tables(0).Rows(i).Item(76)
            programinstal40 = ds.Tables(0).Rows(i).Item(77)
            programinstal41 = ds.Tables(0).Rows(i).Item(78)
            programinstal42 = ds.Tables(0).Rows(i).Item(79)
            programinstal43 = ds.Tables(0).Rows(i).Item(80)
            programinstal44 = ds.Tables(0).Rows(i).Item(81)
            programinstal45 = ds.Tables(0).Rows(i).Item(82)
            programinstal46 = ds.Tables(0).Rows(i).Item(83)
            programinstal47 = ds.Tables(0).Rows(i).Item(84)
            programinstal48 = ds.Tables(0).Rows(i).Item(85)
            programinstal49 = ds.Tables(0).Rows(i).Item(86)
            programinstal50 = ds.Tables(0).Rows(i).Item(87)
            programinstal51 = ds.Tables(0).Rows(i).Item(88)
            programinstal52 = ds.Tables(0).Rows(i).Item(89)
            programinstal53 = ds.Tables(0).Rows(i).Item(90)
            programinstal54 = ds.Tables(0).Rows(i).Item(91)
            programinstal55 = ds.Tables(0).Rows(i).Item(92)
            programinstal56 = ds.Tables(0).Rows(i).Item(93)
            programinstal57 = ds.Tables(0).Rows(i).Item(94)
            programinstal58 = ds.Tables(0).Rows(i).Item(95)
            programinstal59 = ds.Tables(0).Rows(i).Item(96)
            programinstal60 = ds.Tables(0).Rows(i).Item(97)
            programinstal61 = ds.Tables(0).Rows(i).Item(98)
            programinstal62 = ds.Tables(0).Rows(i).Item(99)
            programinstal63 = ds.Tables(0).Rows(i).Item(100)
            programinstal64 = ds.Tables(0).Rows(i).Item(101)
            programinstal65 = ds.Tables(0).Rows(i).Item(102)
            programinstal66 = ds.Tables(0).Rows(i).Item(103)
            programinstal67 = ds.Tables(0).Rows(i).Item(104)
            programinstal68 = ds.Tables(0).Rows(i).Item(105)
            programinstal69 = ds.Tables(0).Rows(i).Item(106)
            programinstal70 = ds.Tables(0).Rows(i).Item(107)
            programinstal71 = ds.Tables(0).Rows(i).Item(108)
            programinstal72 = ds.Tables(0).Rows(i).Item(109)
            programinstal73 = ds.Tables(0).Rows(i).Item(110)
            programinstal74 = ds.Tables(0).Rows(i).Item(111)
            programinstal75 = ds.Tables(0).Rows(i).Item(112)
            programinstal76 = ds.Tables(0).Rows(i).Item(113)
            programinstal77 = ds.Tables(0).Rows(i).Item(114)
            programinstal78 = ds.Tables(0).Rows(i).Item(115)
            programinstal79 = ds.Tables(0).Rows(i).Item(116)
            programinstal80 = ds.Tables(0).Rows(i).Item(117)
            programinstal81 = ds.Tables(0).Rows(i).Item(118)
            programinstal82 = ds.Tables(0).Rows(i).Item(119)
            programinstal83 = ds.Tables(0).Rows(i).Item(120)
            programinstal84 = ds.Tables(0).Rows(i).Item(121)
            programinstal85 = ds.Tables(0).Rows(i).Item(122)
            programinstal86 = ds.Tables(0).Rows(i).Item(123)
            programinstal87 = ds.Tables(0).Rows(i).Item(124)
            programinstal88 = ds.Tables(0).Rows(i).Item(125)
            programinstal89 = ds.Tables(0).Rows(i).Item(126)
            programinstal90 = ds.Tables(0).Rows(i).Item(127)
            programinstal91 = ds.Tables(0).Rows(i).Item(128)
            programinstal92 = ds.Tables(0).Rows(i).Item(129)
            programinstal93 = ds.Tables(0).Rows(i).Item(130)
            programinstal94 = ds.Tables(0).Rows(i).Item(131)

            MontaComando(datacoleta, ",")
            MontaComando(horacoleta, ",")
            MontaComando(nmhost, ",")
            MontaComando(nmuserlogado, ",")
            MontaComando(nmcontdomhost, ",")
            MontaComando(uptimehost, ",")
            MontaComando(timezonehost, ",")
            MontaComando(prochost, ",")
            MontaComando(qtdcorhost, ",")
            MontaComando(nmsoatualhost, ",")
            MontaComando(platsoatualhost, ",")
            MontaComando(lingsoatualhost, ",")
            MontaComando(qtdmemhost, ",")
            MontaComando(qtdmemdisphost, ",")
            MontaComando(discosohost, ",")
            MontaComando(formatdiscosohost, ",")
            MontaComando(tamtotdiscosohost, ",")
            MontaComando(tamdispdiscosohost, ",")
            MontaComando(nomeniccabo, ",")
            MontaComando(descniccabo, ",")
            MontaComando(macaddressniccabo, ",")
            MontaComando(enderipniccabo, ",")
            MontaComando(nomenicsemfio, ",")
            MontaComando(descnicsemfio, ",")
            MontaComando(macaddressnicsemfio, ",")
            MontaComando(enderipnicsemfio, ",")
            MontaComando(placavideo, ",")
            MontaComando(resolucaoatual, ",")
            MontaComando(impressorainst1, ",")
            MontaComando(impressorainst2, ",")
            MontaComando(impressorainst3, ",")
            MontaComando(impressorainst4, ",")
            MontaComando(impressorainst5, ",")
            MontaComando(impressorainst6, ",")
            MontaComando(impressorainst7, ",")
            MontaComando(chavewindows, ",")
            MontaComando(chaveoffice, ",")
            MontaComando(instanciasql, ",")
            MontaComando(programinstal1, ",")
            MontaComando(programinstal2, ",")
            MontaComando(programinstal3, ",")
            MontaComando(programinstal4, ",")
            MontaComando(programinstal5, ",")
            MontaComando(programinstal6, ",")
            MontaComando(programinstal7, ",")
            MontaComando(programinstal8, ",")
            MontaComando(programinstal9, ",")
            MontaComando(programinstal10, ",")
            MontaComando(programinstal11, ",")
            MontaComando(programinstal12, ",")
            MontaComando(programinstal13, ",")
            MontaComando(programinstal14, ",")
            MontaComando(programinstal15, ",")
            MontaComando(programinstal16, ",")
            MontaComando(programinstal17, ",")
            MontaComando(programinstal18, ",")
            MontaComando(programinstal19, ",")
            MontaComando(programinstal20, ",")
            MontaComando(programinstal21, ",")
            MontaComando(programinstal22, ",")
            MontaComando(programinstal23, ",")
            MontaComando(programinstal24, ",")
            MontaComando(programinstal25, ",")
            MontaComando(programinstal26, ",")
            MontaComando(programinstal27, ",")
            MontaComando(programinstal28, ",")
            MontaComando(programinstal29, ",")
            MontaComando(programinstal30, ",")
            MontaComando(programinstal31, ",")
            MontaComando(programinstal32, ",")
            MontaComando(programinstal33, ",")
            MontaComando(programinstal34, ",")
            MontaComando(programinstal35, ",")
            MontaComando(programinstal36, ",")
            MontaComando(programinstal37, ",")
            MontaComando(programinstal38, ",")
            MontaComando(programinstal39, ",")
            MontaComando(programinstal40, ",")
            MontaComando(programinstal41, ",")
            MontaComando(programinstal42, ",")
            MontaComando(programinstal43, ",")
            MontaComando(programinstal44, ",")
            MontaComando(programinstal45, ",")
            MontaComando(programinstal46, ",")
            MontaComando(programinstal47, ",")
            MontaComando(programinstal48, ",")
            MontaComando(programinstal49, ",")
            MontaComando(programinstal50, ",")
            MontaComando(programinstal51, ",")
            MontaComando(programinstal52, ",")
            MontaComando(programinstal53, ",")
            MontaComando(programinstal54, ",")
            MontaComando(programinstal55, ",")
            MontaComando(programinstal56, ",")
            MontaComando(programinstal57, ",")
            MontaComando(programinstal58, ",")
            MontaComando(programinstal59, ",")
            MontaComando(programinstal60, ",")
            MontaComando(programinstal61, ",")
            MontaComando(programinstal62, ",")
            MontaComando(programinstal63, ",")
            MontaComando(programinstal64, ",")
            MontaComando(programinstal65, ",")
            MontaComando(programinstal66, ",")
            MontaComando(programinstal67, ",")
            MontaComando(programinstal68, ",")
            MontaComando(programinstal69, ",")
            MontaComando(programinstal70, ",")
            MontaComando(programinstal71, ",")
            MontaComando(programinstal72, ",")
            MontaComando(programinstal73, ",")
            MontaComando(programinstal74, ",")
            MontaComando(programinstal75, ",")
            MontaComando(programinstal76, ",")
            MontaComando(programinstal77, ",")
            MontaComando(programinstal78, ",")
            MontaComando(programinstal79, ",")
            MontaComando(programinstal80, ",")
            MontaComando(programinstal81, ",")
            MontaComando(programinstal82, ",")
            MontaComando(programinstal83, ",")
            MontaComando(programinstal84, ",")
            MontaComando(programinstal85, ",")
            MontaComando(programinstal86, ",")
            MontaComando(programinstal87, ",")
            MontaComando(programinstal88, ",")
            MontaComando(programinstal89, ",")
            MontaComando(programinstal90, ",")
            MontaComando(programinstal91, ",")
            MontaComando(programinstal92, ",")
            MontaComando(programinstal93, ",")
            MontaComando(programinstal94, ",")
            GravaLog("Antes da Remoção --> " & StringComandoColeta)
            StringComandoColeta = StringComandoColeta.Remove(StringComandoColeta.Length - 1)
            GravaLog("Depois da Remoção --> " & StringComandoColeta)
            ComandoImportacao = "Insert into Coletas (datacoleta,horacoleta,nmhost,nmuserlogado,nmcontdomhost,uptimehost,timezonehost,prochost,qtdcorhost,nmsoatualhost,platsoatualhost,lingsoatualhost,qtdmemhost,qtdmemdisphost,discosohost,formatdiscosohost,tamtotdiscosohost,tamdispdiscosohost,nomeniccabo,descniccabo,macaddressniccabo,enderipniccabo,nomenicsemfio,descnicsemfio,macaddressnicsemfio,enderipnicsemfio,placavideo,resolucaoatual,impressorainst1,impressorainst2,impressorainst3,impressorainst4,impressorainst5,impressorainst6,impressorainst7,chavewindows,chaveoffice,instanciasql,programinstal1,programinstal2,programinstal3,programinstal4,programinstal5,programinstal6,programinstal7,programinstal8,programinstal9,programinstal10,programinstal11,programinstal12,programinstal13,programinstal14,programinstal15,programinstal16,programinstal17,programinstal18,programinstal19,programinstal20,programinstal21,programinstal22,programinstal23,programinstal24,programinstal25,programinstal26,programinstal27,programinstal28,programinstal29,programinstal30,programinstal31,programinstal32,programinstal33,programinstal34,programinstal35,programinstal36,programinstal37,programinstal38,programinstal39,programinstal40,programinstal41,programinstal42,programinstal43,programinstal44,programinstal45,programinstal46,programinstal47,programinstal48,programinstal49,programinstal50,programinstal51,programinstal52,programinstal53,programinstal54,programinstal55,programinstal56,programinstal57,programinstal58,programinstal59,programinstal60,programinstal61,programinstal62,programinstal63,programinstal64,programinstal65,programinstal66,programinstal67,programinstal68,programinstal69,programinstal70,programinstal71,programinstal72,programinstal73,programinstal74,programinstal75,programinstal76,programinstal77,programinstal78,programinstal79,programinstal80,programinstal81,programinstal82,programinstal83,programinstal84,programinstal85,programinstal86,programinstal87,programinstal88,programinstal89,programinstal90,programinstal91,programinstal92,programinstal93,programinstal94) values (" & StringComandoColeta & ")"
            ExecutaComando(ComandoImportacao)
        Next
        Return True
    End Function

    Public Function CadastraUsuario(DataHoje As Date, NomeUsuario As String, PapelUsuario As String, ArquivoFoto As String)
        Using ConexaoBanco As New SqlConnection(MontaStringDeConexao())
            ConexaoBanco.Open()
            Using cmd = New SqlCommand("INSERT INTO Usuarios(datacadastro,nmuser,papelUser,imageUser) VALUES (@datacadastro,@nmuser,@papelUser,@imageUser)", ConexaoBanco)
                cmd.Parameters.AddWithValue("@datacadastro", DataHoje)
                cmd.Parameters.AddWithValue("@nmuser", NomeUsuario)
                cmd.Parameters.AddWithValue("@papelUser", PapelUsuario)
                cmd.Parameters.AddWithValue("@imageUser", File.ReadAllBytes(ArquivoFoto))
                cmd.ExecuteNonQuery()
            End Using
        End Using
        Return True
    End Function
    'Sub Main()
    'Do While True
    '       Thread.Sleep(25000)
    '       CriaXML()
    '       
    'Loop
    'End Sub
End Module
