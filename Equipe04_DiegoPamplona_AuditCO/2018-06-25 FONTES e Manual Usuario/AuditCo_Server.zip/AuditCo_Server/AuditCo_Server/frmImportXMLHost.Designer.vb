﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmImportXMLHost
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btImportXML = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbxmlaimportar = New System.Windows.Forms.TextBox()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.btLocalizarXML = New System.Windows.Forms.Button()
        Me.tvxmlimportado = New System.Windows.Forms.TreeView()
        Me.ofdabrirxml = New System.Windows.Forms.OpenFileDialog()
        Me.SuspendLayout()
        '
        'btImportXML
        '
        Me.btImportXML.Location = New System.Drawing.Point(139, 37)
        Me.btImportXML.Name = "btImportXML"
        Me.btImportXML.Size = New System.Drawing.Size(87, 23)
        Me.btImportXML.TabIndex = 0
        Me.btImportXML.Text = "Importar XML"
        Me.btImportXML.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(108, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "XML a ser Importado:"
        '
        'tbxmlaimportar
        '
        Me.tbxmlaimportar.Location = New System.Drawing.Point(128, 5)
        Me.tbxmlaimportar.Name = "tbxmlaimportar"
        Me.tbxmlaimportar.Size = New System.Drawing.Size(185, 20)
        Me.tbxmlaimportar.TabIndex = 2
        Me.tbxmlaimportar.Text = "c:\temp\NBBNU002.xml"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(16, 66)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(363, 23)
        Me.ProgressBar1.TabIndex = 3
        Me.ProgressBar1.Value = 50
        '
        'btLocalizarXML
        '
        Me.btLocalizarXML.Location = New System.Drawing.Point(319, 3)
        Me.btLocalizarXML.Name = "btLocalizarXML"
        Me.btLocalizarXML.Size = New System.Drawing.Size(59, 23)
        Me.btLocalizarXML.TabIndex = 4
        Me.btLocalizarXML.Text = "Localizar"
        Me.btLocalizarXML.UseVisualStyleBackColor = True
        '
        'tvxmlimportado
        '
        Me.tvxmlimportado.Location = New System.Drawing.Point(16, 96)
        Me.tvxmlimportado.Name = "tvxmlimportado"
        Me.tvxmlimportado.Size = New System.Drawing.Size(363, 315)
        Me.tvxmlimportado.TabIndex = 5
        '
        'ofdabrirxml
        '
        Me.ofdabrirxml.FileName = "OpenFileDialog1"
        '
        'frmImportXMLHost
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(391, 445)
        Me.Controls.Add(Me.tvxmlimportado)
        Me.Controls.Add(Me.btLocalizarXML)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.tbxmlaimportar)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btImportXML)
        Me.Name = "frmImportXMLHost"
        Me.Text = "AuditCo - Server. - Importar XML"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btImportXML As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents tbxmlaimportar As TextBox
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents btLocalizarXML As Button
    Friend WithEvents tvxmlimportado As TreeView
    Friend WithEvents ofdabrirxml As OpenFileDialog
End Class
