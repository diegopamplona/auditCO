﻿Imports System.Data.SqlClient

Public Class frmPrincipal
    Dim ConexaoBanco As New SqlConnection(MontaStringDeConexao())
    Private Sub CadastrarUsuáriosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CadastrarUsuáriosToolStripMenuItem.Click
        frmCadUsuario.Show()

    End Sub
    Private Sub ImportarXMLDeCadastroToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ImportarXMLDeCadastroToolStripMenuItem.Click
        frmImportXMLHost.Show()

    End Sub

    Private Sub CadastrarInformaçõesAdicionaisToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CadastrarInformaçõesAdicionaisToolStripMenuItem.Click
        frmCadastrarInfAddHost.Show()

    End Sub

    Private Sub RelToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RelToolStripMenuItem.Click
        frmReportComputadores.ShowDialog()

    End Sub

    Private Sub LoginToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub frmPrincipal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            ConexaoBanco.Open()
            If ConexaoBanco.State = ConnectionState.Open Then
                GravaLog("Programa AuditCo Conectado a Base de Dados com Sucesso")
            Else
                GravaLog("Programa AuditCo Não Conectao a Base de Dados")
            End If
            Teste.UsuariosDataTable
        Catch ex As Exception
            GravaLog(ex.Message)
        End Try

    End Sub

    Private Sub RelUsuariosCadastradosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RelUsuariosCadastradosToolStripMenuItem.Click
        RelatorioTeste.Show()
    End Sub
End Class
