﻿Imports System.Threading
Imports System.Data.SqlClient

Public Class Service1
    Dim tempoColeta As Integer = PegaParametro("GERAL", "TEMPOCOLETA")
    Protected Overrides Sub OnStart(ByVal args() As String)
        Try
            Do While True
                Thread.Sleep(tempoColeta)
                ExecutaColeta()
                If PegaParametro("GERAL", "CRIAXML") = "SIM" Then
                    CriaXML()
                End If
            Loop

        Catch ex As Exception
            GravaLog("Erro de Execução Serviço:" & ex.Message)
            GravaLog("Erro de Execução Serviço: " & ex.Source)
            GravaLog("Erro de Execução Serviço: " & ex.HelpLink)
            GravaLog("Erro de Execução Serviço: " & ex.StackTrace)
        End Try
    End Sub

    Protected Overrides Sub OnStop()
        Try
            GravaLog("Encerrando o Serviço")
        Catch ex As Exception
            GravaLog("Erro Stop Serviço:" & ex.Message)
            GravaLog("Erro Stop Serviço: " & ex.Source)
            GravaLog("Erro Stop Serviço: " & ex.HelpLink)
            GravaLog("Erro Stop Serviço: " & ex.StackTrace)
        End Try
    End Sub

End Class
